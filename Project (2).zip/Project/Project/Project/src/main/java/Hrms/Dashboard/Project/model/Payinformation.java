package Hrms.Dashboard.Project.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "payinformation")
public class Payinformation {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name="payinformation_id") 
	    private Long payinformationId;
	 
	    @Column(name="basic_pay") 
	    private Long basicPay;
	 
	   @Column(name="ta_da") 
	    private Long taDa;
	    
	    @Column(name="hra") 
	    private Long hra;
	    
	    @Column(name="tpt")  
	    private Long tpt;
	    
	    @Column(name="pers_pay") 
	    private Long  persPay;
	    
	    @Column(name="govt_perks")  
	    private Long govtPerks;
	    
	    @Column(name="emp_Id")  
	    private String empId;
	    
	    @Column(name="total_pay")  
	    private Double totalPay;

		public Payinformation() {
			super();
		
		}

		public Payinformation(Long payinformationId, Long basicPay, Long taDa, Long hra, Long tpt, Long persPay,
				Long govtPerks, String empId, Double totalPay) {
			super();
			this.payinformationId = payinformationId;
			this.basicPay = basicPay;
			this.taDa = taDa;
			this.hra = hra;
			this.tpt = tpt;
			this.persPay = persPay;
			this.govtPerks = govtPerks;
			this.empId = empId;
			this.totalPay = totalPay;
		}

		public Long getPayinformationId() {
			return payinformationId;
		}

		public void setPayinformationId(Long payinformationId) {
			this.payinformationId = payinformationId;
		}

		public Long getBasicPay() {
			return basicPay;
		}

		public void setBasicPay(Long basicPay) {
			this.basicPay = basicPay;
		}

		public Long getTaDa() {
			return taDa;
		}

		public void setTaDa(Long taDa) {
			this.taDa = taDa;
		}

		public Long getHra() {
			return hra;
		}

		public void setHra(Long hra) {
			this.hra = hra;
		}

		public Long getTpt() {
			return tpt;
		}

		public void setTpt(Long tpt) {
			this.tpt = tpt;
		}

		public Long getPersPay() {
			return persPay;
		}

		public void setPersPay(Long persPay) {
			this.persPay = persPay;
		}

		public Long getGovtPerks() {
			return govtPerks;
		}

		public void setGovtPerks(Long govtPerks) {
			this.govtPerks = govtPerks;
		}

		public String getEmpId() {
			return empId;
		}

		public void setEmpId(String empId) {
			this.empId = empId;
		}

		public Double getTotalPay() {
			return totalPay;
		}

		public void setTotalPay(Double totalPay) {
			this.totalPay = totalPay;
		}

		@Override
		public String toString() {
			return "Payinformation [payinformationId=" + payinformationId + ", basicPay=" + basicPay + ", taDa=" + taDa
					+ ", hra=" + hra + ", tpt=" + tpt + ", persPay=" + persPay + ", govtPerks=" + govtPerks + ", empId="
					+ empId + ", totalPay=" + totalPay + "]";
		}

		

}
