package Hrms.Dashboard.Project.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import Hrms.Dashboard.Project.constant.MessageConstant;
import Hrms.Dashboard.Project.dao.UserDto;
import Hrms.Dashboard.Project.dao.UserEmployeeIDResponse;
import Hrms.Dashboard.Project.dao.UserLogInResponse;
import Hrms.Dashboard.Project.dao.UserLoginRequest;
import Hrms.Dashboard.Project.dao.UserRequest;
import Hrms.Dashboard.Project.dao.UserResponse;
import Hrms.Dashboard.Project.exception.AlreadyExistsException;
import Hrms.Dashboard.Project.exception.CreateUserException;
import Hrms.Dashboard.Project.exception.InvalidEmployeeIdException;
import Hrms.Dashboard.Project.exception.NotFoundException;
import Hrms.Dashboard.Project.model.User;
import Hrms.Dashboard.Project.repositoty.SectionInchargeRepo;
import Hrms.Dashboard.Project.repositoty.UserRepo;

@Service
public class UserService implements UserInterface{
	
	@Autowired
	private UserRepo userRepo;
	
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	



	@Override
	public UserResponse ceateNewUser(UserRequest request) throws IOException{
	
		 String empId = request.getEmpId() ;						
		 String userName =request.getUserName();
	     String userEmail = request.getUserEmail();
		 String hashPassword = request.getHashPassword();
	
		 
		 if (ObjectUtils.isEmpty(empId) || ObjectUtils.isEmpty(userName) || ObjectUtils.isEmpty(userEmail)) {
			 throw new CreateUserException(MessageConstant.Please_fullfilled_All_MANDATORY_fiellds);
			 }
		 
		  if(!ObjectUtils.isEmpty(userRepo.findByEmpId(empId))) {
			 throw new AlreadyExistsException(MessageConstant.EMPLOYEE_ID_ALREADY_EXIST_ENTER_ANOTHER_EMPLOYEE_ID);
		 }
		  
		   if ( !ObjectUtils.isEmpty(userRepo.findByEmail(userEmail))){
			  throw new AlreadyExistsException(MessageConstant.EMAIL_ALREADY_EXIST_ENTER_ANOTHER_EMAIL);  
		  }
	
		  
		  User user = new User();
		  BeanUtils.copyProperties(request, user);
		  String encodedPwd = passwordEncoder.encode(hashPassword);
		  user.setHashPassword(encodedPwd);
		  
		  User savedUser = userRepo.save(user);
          UserResponse userResponse = new UserResponse();
          BeanUtils.copyProperties(userResponse, savedUser);
		  
		return userResponse;
	}


	@Override
	public UserLogInResponse userLogIn(UserLoginRequest request) throws Exception {
	    String empId = request.getEmpId();
	    String hashPassword = request.getHashPassword();

	    if (ObjectUtils.isEmpty(empId) || ObjectUtils.isEmpty(hashPassword)) {
	        throw new CreateUserException(MessageConstant.Please_fullfilled_All_MANDATORY_fiellds);
	    }

	    User existingUser = userRepo.findByEmpId(empId);
	    if (existingUser == null)  {
	        throw new NotFoundException(MessageConstant.INVALID_EMPID);
	    }


	    if (!passwordEncoder.matches(hashPassword, existingUser.getHashPassword())) {
	        throw new NotFoundException(MessageConstant.INVALID_PASSWORD);
	    }
	    
	    UserLogInResponse userLogInResponse = new UserLogInResponse();
	    BeanUtils.copyProperties(existingUser, userLogInResponse);


	    return userLogInResponse;
	}



	@Override
	public List<UserResponse> getUserList() {
	    return userRepo.findAllUsers().stream()
	            .map(user -> {
	                UserResponse response = new UserResponse();
	                response.setEmpId(user.getEmpId());
	                response.setUserName(user.getUserName());
	                response.setUserEmail(user.getUserEmail());
	                return response;
	            })
	            .collect(Collectors.toList());
	}


	@Override
	public User updateUser(User request) {
		User user = userRepo.findByEmpId(request.getEmpId());
		 if(user == null) {
			throw new InvalidEmployeeIdException(request);
		}
		
		 else {
			 user.setUserName(request.getUserName());
			 user.setUserEmail(request.getUserEmail());
			 user.setUserRoles(request.getUserRoles());
			 user.setSectionIncharge(request.getSectionIncharge());
		 }
		 
			    return userRepo.save(user);
	}


	
	@Override
	public List<UserEmployeeIDResponse> getUserEmployeeIdList() {
	    return userRepo.findAll().stream().map(user -> {
	        UserEmployeeIDResponse response = new UserEmployeeIDResponse();
	        response.setEmpId(user.getEmpId());
	        response.setUserName(user.getUserName());
	        return response;
	    }).collect(Collectors.toList());
	}






	}
	
