package Hrms.Dashboard.Project.repositoty;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import Hrms.Dashboard.Project.dao.UserDto;
import Hrms.Dashboard.Project.dao.UserResponse;
import Hrms.Dashboard.Project.model.User;

@Repository
public interface UserRepo extends JpaRepository<User, Integer>{

 
	
    public User findByEmpId(String empId);

	@Query(nativeQuery = true , value = "select us.user_email from user as us  where us.user_email =:userEmail")
    public String findByEmail(@Param("userEmail") String userEmail);

	@Query(nativeQuery = true , value ="select * from user ")
	List<User> findAllUsers();

	@Query(nativeQuery = true, value = "SELECT emp_Id ,user_name FROM user")
	List<String> findAllEmployeeIds();
	

	public String save(String user);


}
