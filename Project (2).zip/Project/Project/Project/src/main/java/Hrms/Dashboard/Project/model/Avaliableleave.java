package Hrms.Dashboard.Project.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "availableleave")
public class Avaliableleave {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="availableleave_id")
	private Integer availableleaveId;
	
	@Column(name="el")
	private Integer el;						
	
	@Column(name ="cl")
	private Integer cl;
	
	@Column(name ="commuted_hpl")
	private Integer commutedHpl;
	
	@Column(name ="hpl")
	private Integer hpl;
	
	@Column(name ="otl_comp_off")
	private Integer otlCompOff;
	
	@Column(name ="eol_without_mc")
	private Integer eolWithoutMc;
	
	@Column(name ="ccl")
	private Integer ccl;
	
	@Column(name ="paternity_leave")
	private Integer paternityLeave;
	
	@Column(name ="maternity_leave")
	private Integer maternityLeave;
	
	@Column(name ="eol_with_mc")
	private Integer eolWithMc;
	
	
	
	@Column(name ="ssl_leave")
	private Integer sslLeave;
	
	  
    @Column(name= "emp_Id")
    private String empId;

	public Avaliableleave() {
		super();
		
	}

	

	

	public Avaliableleave(Integer availableleaveId, Integer el, Integer cl, Integer commutedHpl, Integer hpl, Integer otlCompOff,
			Integer eolWithoutMc, Integer ccl, Integer paternityLeave, Integer maternityLeave, Integer eolWithMc, Integer sslLeave,
			String empId) {
		super();
		this.availableleaveId = availableleaveId;
		this.el = el;
		this.cl = cl;
		this.commutedHpl = commutedHpl;
		this.hpl = hpl;
		this.otlCompOff = otlCompOff;
		this.eolWithoutMc = eolWithoutMc;
		this.ccl = ccl;
		this.paternityLeave = paternityLeave;
		this.maternityLeave = maternityLeave;
		this.eolWithMc = eolWithMc;
		this.sslLeave = sslLeave;
		this.empId = empId;
	}





	public Integer getAvailableleaveId() {
		return availableleaveId;
	}





	public void setAvailableleaveId(Integer availableleaveId) {
		this.availableleaveId = availableleaveId;
	}





	public Integer getEl() {
		return el;
	}





	public void setEl(Integer el) {
		this.el = el;
	}





	public Integer getCl() {
		return cl;
	}





	public void setCl(Integer cl) {
		this.cl = cl;
	}





	public Integer getCommutedHpl() {
		return commutedHpl;
	}





	public void setCommutedHpl(Integer commutedHpl) {
		this.commutedHpl = commutedHpl;
	}





	public Integer getHpl() {
		return hpl;
	}





	public void setHpl(Integer hpl) {
		this.hpl = hpl;
	}





	public Integer getOtlCompOff() {
		return otlCompOff;
	}





	public void setOtlCompOff(Integer otlCompOff) {
		this.otlCompOff = otlCompOff;
	}





	public Integer getEolWithoutMc() {
		return eolWithoutMc;
	}





	public void setEolWithoutMc(Integer eolWithoutMc) {
		this.eolWithoutMc = eolWithoutMc;
	}





	public Integer getCcl() {
		return ccl;
	}





	public void setCcl(Integer ccl) {
		this.ccl = ccl;
	}





	public Integer getPaternityLeave() {
		return paternityLeave;
	}





	public void setPaternityLeave(Integer paternityLeave) {
		this.paternityLeave = paternityLeave;
	}





	public Integer getMaternityLeave() {
		return maternityLeave;
	}





	public void setMaternityLeave(Integer maternityLeave) {
		this.maternityLeave = maternityLeave;
	}





	public Integer getEolWithMc() {
		return eolWithMc;
	}





	public void setEolWithMc(Integer eolWithMc) {
		this.eolWithMc = eolWithMc;
	}





	public Integer getSslLeave() {
		return sslLeave;
	}





	public void setSslLeave(Integer sslLeave) {
		this.sslLeave = sslLeave;
	}





	public String getEmpId() {
		return empId;
	}





	public void setEmpId(String empId) {
		this.empId = empId;
	}





	@Override
	public String toString() {
		return "Avaliableleave [availableleaveId=" + availableleaveId + ", el=" + el + ", cl=" + cl + ", commutedHpl="
				+ commutedHpl + ", hpl=" + hpl + ", otlCompOff=" + otlCompOff + ", eolWithoutMc=" + eolWithoutMc
				+ ", ccl=" + ccl + ", paternityLeave=" + paternityLeave + ", maternityLeave=" + maternityLeave
				+ ", eolWithMc=" + eolWithMc + ", sslLeave=" + sslLeave + ", empId=" + empId + "]";
	}





	



	



	
}
