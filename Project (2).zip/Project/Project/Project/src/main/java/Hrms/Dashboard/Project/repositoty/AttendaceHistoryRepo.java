package Hrms.Dashboard.Project.repositoty;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import Hrms.Dashboard.Project.model.AttendaceHistory;


@Repository
public interface AttendaceHistoryRepo extends  JpaRepository<AttendaceHistory, Integer>{

	
	@Query(nativeQuery = true , value ="select * from  attendace_history us where us.emp_Id =:empId ")
	List<AttendaceHistory> findAllByEmpId(@Param("empId")  String empId);
	
	
	@Query(nativeQuery = true , value ="select * from  attendace_history us where us.check_in_date =:checkInDate")
	AttendaceHistory findByDate( @Param("checkInDate")LocalDate checkInDate);

	
	@Query(nativeQuery = true , value ="SELECT * FROM attendace_history us WHERE us.emp_Id = :empId ORDER BY check_in_time DESC LIMIT 1")  
	AttendaceHistory findById(@Param("empId") String empId);



	@Query(nativeQuery = true, value =
		    "SELECT ah.id, " +
		    "       ah.emp_Id, " +
		    "       ah.check_in_date, " +
		    "       ah.check_in_time, " +
		    "       ah.check_out_time, " +
		    "       ah.working_hours, " +
		    "       ah.working_minutes, " +
		    "       ah.attendance_status,"+
		    "       u.user_name, " +
		    "       emp.trade " +
		 
		    "FROM attendace_history AS ah " +
		    "JOIN user AS u ON ah.emp_Id = u.emp_Id " +
		    "LEFT JOIN employee AS emp ON ah.emp_Id = emp.emp_Id"
		)
		public List<AttendaceHistory> findAllActiveUser();



	 @Query(nativeQuery = true ,value="SELECT a FROM attendace_history a WHERE YEAR(a.check_in_date) = :year AND MONTH(a.check_in_date) = :month")
	    List<AttendaceHistory> findAllActiveUserByMonth(@Param("year") int year, @Param("month") int month);

	 @Query(nativeQuery = true ,value="SELECT DISTINCT a.check_in_date FROM attendace_history a WHERE a.emp_Id = :empId ")
    List<LocalDate> findAttendanceDatesByEmployeeId(String empId);

 


	 @Query(value = "SELECT * FROM attendace_history " +
             "WHERE emp_Id = :empId " +
             "AND check_in_date = :currentDate " +
             "ORDER BY check_in_time DESC " +
             "LIMIT 1", nativeQuery = true)
AttendaceHistory findLatestByEmpIdAndDate(@Param("empId") String empId, @Param("currentDate") LocalDate currentDate);


	boolean existsByEmpIdAndCheckInDate(String empId, LocalDate date);
}
