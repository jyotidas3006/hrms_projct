package Hrms.Dashboard.Project.repositoty;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Hrms.Dashboard.Project.dao.EmployeeImageUploadeResponse;
import Hrms.Dashboard.Project.model.Avaliableleave;
import Hrms.Dashboard.Project.model.Employee;

@Repository
public interface EmployeeLeaveRepo extends JpaRepository<Avaliableleave, Integer>{

	public EmployeeImageUploadeResponse save(Employee fileDB);
	
	public Avaliableleave findByEmpId( String empId);

}
