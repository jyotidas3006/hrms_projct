package Hrms.Dashboard.Project.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.expression.SecurityExpressionHandler;
import org.springframework.security.config.annotation.ObjectPostProcessor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.WebInvocationPrivilegeEvaluator;

import Hrms.Dashboard.Project.service.UserInterface;
import Hrms.Dashboard.Project.service.UserService;
import jakarta.servlet.Filter;

@Configuration
@EnableWebSecurity
public class SpringSecurityConfiguration  {
	
	
	
	
	
	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http, UserDetailsService userDetailsService) throws Exception {
	    http
	        .cors().disable()
	        .csrf().disable()
	        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
	        .and()
	        .authorizeRequests()
	        .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
	        .requestMatchers("/").permitAll()
	             .requestMatchers("/admin/**").hasRole("ADMIN")
	            .requestMatchers("/user/**").permitAll()
	            .requestMatchers("/hrms/dashboard/**").permitAll()
	            .requestMatchers("/hrms/attendance/**").permitAll()
	            .requestMatchers("/hrms/sectionincharge/**").permitAll()
	            .anyRequest().authenticated()
	        .and()
	        .formLogin()
	            .loginPage("/login")
	            .loginProcessingUrl("/loginPage")
	            .defaultSuccessUrl("/user/dashboard");
	           

	    return http.getOrBuild();
	}

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
	
		auth.inMemoryAuthentication().passwordEncoder(NoOpPasswordEncoder.getInstance()).withUser("hrms").password("12345").roles("USER");	
	}
	

	@Bean
	public BCryptPasswordEncoder  passwordEncoder() {
	        return new BCryptPasswordEncoder();
	    }
	

}
