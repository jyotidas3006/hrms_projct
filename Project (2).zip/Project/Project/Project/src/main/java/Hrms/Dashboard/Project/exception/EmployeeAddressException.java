package Hrms.Dashboard.Project.exception;

public class EmployeeAddressException  extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmployeeAddressException() {
		super();
		
	}

	

	public EmployeeAddressException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public EmployeeAddressException(String message) {
		super(message);
		
	}

	
	

}
