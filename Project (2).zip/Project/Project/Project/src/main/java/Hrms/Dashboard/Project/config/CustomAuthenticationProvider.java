//package Hrms.Dashboard.Project.config;
//
//import java.io.IOException;
//import java.io.PrintWriter;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.filter.GenericFilterBean;
//
//import Hrms.Dashboard.Project.constant.MessageConstant;
//import Hrms.Dashboard.Project.model.User;
//import jakarta.servlet.FilterChain;
//import jakarta.servlet.ServletException;
//import jakarta.servlet.ServletRequest;
//import jakarta.servlet.ServletResponse;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//
//public class CustomAuthenticationProvider  extends GenericFilterBean{
//	
//
//	
//	@Autowired
//    private User user; 
//
//
//	public CustomAuthenticationProvider( User user) {
//	
//		this.user=user;
//	}
//
//
//
//	@Override
//	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
//			throws IOException, ServletException {
//		
//		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
//		HttpServletResponse httpServletResponse = (HttpServletResponse) response;
//		
//		//String token = httpServletRequest.getHeader(MessageConstant.HEADER_STRING);
//		
//		if(httpServletRequest.getRequestURI().equalsIgnoreCase("/user/login")
//				||httpServletRequest.getRequestURI().equalsIgnoreCase("/user/singup")
//			
//				
//				) {
//			chain.doFilter(request, response);
//		}
//		
//		
//	
//	}
//	
//	
//	}
//
