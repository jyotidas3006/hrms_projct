package Hrms.Dashboard.Project.service;

import java.util.List;

import Hrms.Dashboard.Project.dao.UserEmployeeIDResponse;
import Hrms.Dashboard.Project.dao.UserLogInResponse;
import Hrms.Dashboard.Project.dao.UserLoginRequest;
import Hrms.Dashboard.Project.dao.UserRequest;
import Hrms.Dashboard.Project.dao.UserResponse;
import Hrms.Dashboard.Project.model.User;

public interface UserInterface {
	
	public UserResponse ceateNewUser(UserRequest request ) throws Exception;

	public UserLogInResponse userLogIn(UserLoginRequest request ) throws Exception;
	
	public List<UserResponse> getUserList();
	
	public  User  updateUser(User request ); 

	public List<UserEmployeeIDResponse> getUserEmployeeIdList();
	

	
	
}
