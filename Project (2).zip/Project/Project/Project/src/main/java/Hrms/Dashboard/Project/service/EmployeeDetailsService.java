package Hrms.Dashboard.Project.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import Hrms.Dashboard.Project.constant.MessageConstant;
import Hrms.Dashboard.Project.dao.EmployeeListResponce;
import Hrms.Dashboard.Project.dao.PayinformationRequest;
import Hrms.Dashboard.Project.dao.PayinformationResponse;
import Hrms.Dashboard.Project.exception.AlreadyExistsException;
import Hrms.Dashboard.Project.exception.EmployeeAddressException;
import Hrms.Dashboard.Project.exception.InvalidEmployeeIdException;
import Hrms.Dashboard.Project.model.Avaliableleave;
import Hrms.Dashboard.Project.model.ContactInformation;
import Hrms.Dashboard.Project.model.Employee;
import Hrms.Dashboard.Project.model.Payinformation;
import Hrms.Dashboard.Project.model.User;
import Hrms.Dashboard.Project.repositoty.ContactInformationRepo;
import Hrms.Dashboard.Project.repositoty.EmployeeDetailsRepo;
import Hrms.Dashboard.Project.repositoty.EmployeeLeaveRepo;
import Hrms.Dashboard.Project.repositoty.PayinformationRepo;

@Service
public class EmployeeDetailsService  implements EmployeeDetailsInterface{

	@Autowired
	private EmployeeDetailsRepo employeeDetailsRepo;
	
	@Autowired
	private	EmployeeLeaveRepo employeeLeaveRepo;
	
	@Autowired
	private PayinformationRepo payinformationRepo;
	
	
	@Autowired
	private ContactInformationRepo contactInformationRepo;

	
	
	@Override
	public Employee addEmpolyeeDetails(Employee empRequest) {
	    Employee existingEmployee = employeeDetailsRepo.findByEmpId(empRequest.getEmpId());

	    if (existingEmployee != null) {
	        throw new AlreadyExistsException(MessageConstant.EMPLOYEE_ID_ALREADY_EXIST_ENTER_ANOTHER_EMPLOYEE_ID);
	    }

	 
	    return employeeDetailsRepo.save(empRequest);
	}

	@Override
	public List<EmployeeListResponce> getEmpolyeeList() {
	    List<Employee> empList = employeeDetailsRepo.findAllEmployee();

	    return empList.stream().map(emp -> {
	        EmployeeListResponce empResponse = new EmployeeListResponce();
	        empResponse.setEmpId(emp.getEmpId());
	        empResponse.setEmpName(emp.getUser().getUserName());
	        empResponse.setGender(emp.getGender());
	        empResponse.setDateOfJoining(emp.getDateOfJoining());
	        empResponse.setDateOfRetirement(emp.getDateOfRetirement());
	        empResponse.setAlternativeNo(emp.getContact().getAlternativeNo()); 
	        empResponse.setMobileNo(emp.getContact().getMobileNo()); 
	        return empResponse;
	    }).collect(Collectors.toList());
	}



	
	@Override
	public List<Avaliableleave> getEmpolyeeLeaveList() {
		return employeeLeaveRepo.findAll();
	}
	
	
	@Override
	public Avaliableleave addEmployeeLeave(Avaliableleave avaliableleave) {
		
		Avaliableleave user = employeeLeaveRepo.findByEmpId(avaliableleave.getEmpId());
		
		  if(ObjectUtils.isEmpty(user)) {
				throw new AlreadyExistsException (MessageConstant.EMPLOYEE_ID_ALREADY_EXIST_ENTER_ANOTHER_EMPLOYEE_ID);
			}
		 else
			 
		return employeeLeaveRepo.save(avaliableleave);
		
		}

	@Override
	public PayinformationResponse addEmployeepayment(PayinformationRequest payinformationRequest) {
		
		        long basic = payinformationRequest.getBasicPay();
				double hra = basic*0.10;  // 10% of basic
		        double da = basic*0.08;   // 8% of basic
		        long tpt = payinformationRequest.getTpt();
		        long perspay = payinformationRequest.getPersPay();
		        long govtperks = payinformationRequest.getGovtPerks();
		        double totalpay = basic +hra+ da+ tpt+perspay+govtperks;
		        String empId= payinformationRequest.getEmpId();
		        
		        Payinformation payinformation=  new Payinformation();
		        payinformation.setBasicPay(basic);
		        payinformation.setHra((long) hra);
		        payinformation.setTaDa((long) da);
		        payinformation.setTpt(tpt);
		        payinformation.setPersPay(perspay);
		        payinformation.setGovtPerks(govtperks);
		        payinformation.setTotalPay(totalpay);
		        payinformation.setEmpId(empId);
		        
		        PayinformationResponse payinformationResponse = new PayinformationResponse();
		        
		        payinformationRepo.save(payinformation);
				
		        return payinformationResponse ;
		       
		
		
		
	}

	@Override
	public ContactInformation addEmpolyeeContactInformation(ContactInformation contactInformation) {
		 //String email = contactInformation.getEmail();
		 String phone = contactInformation.getMobileNo();
		 String alternativeno = contactInformation.getAlternativeNo();
		 String temporary_address = contactInformation.getTemporaryAddress();
		 String permanent_address = contactInformation.getPermanentAddress();
		 String marriage = contactInformation.getMarriageStatus();
		
		 
		 
		 
		 if (ObjectUtils.isEmpty(phone) || ObjectUtils.isEmpty(marriage) || ObjectUtils.isEmpty(permanent_address)){
				throw new EmployeeAddressException(MessageConstant.FIELD_NOT_NULL);
			}
			
	
		return contactInformationRepo.save(contactInformation);
		
		
		
		
		
	}

	@Override
	public Employee  uploadeIndividualPhoto(MultipartFile file) throws IOException{
		
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		Employee FileDB = new Employee(fileName , file.getContentType(), file.getBytes());
		return employeeDetailsRepo.save(FileDB);
		

		
	}

	@Override
	public Employee updateEmployeeDetails(Employee employee) {
		 Employee emp =  employeeDetailsRepo.findByEmpId(employee.getEmpId());
		 
		 if (emp == null) {
			 throw new InvalidEmployeeIdException(employee);
		 }
		 else {
			 emp.setAadharNo(employee.getAadharNo());
			 emp.setBloodGroup(employee.getBloodGroup());
			 emp.setCategory(employee.getCategory());
			 emp.setDateOfBirth(employee.getDateOfBirth());
			 emp.setDateOfJoining(employee.getDateOfJoining());
			 emp.setDateOfRetirement(employee.getDateOfRetirement());
			 emp.setEmployeeType(employee.getEmployeeType());
			 emp.setGender(employee.getGender());
			 emp.setJobType(employee.getJobType());
			 emp.setPhysicallyChallenged(employee.getPhysicallyChallenged());
			 emp.setRemarks(employee.getRemarks());
			 emp.setTrade(employee.getTrade());
			 emp.setGpfOpsNpsNo(employee.getGpfOpsNpsNo());
			 emp.setGrade(employee.getGrade());
			 emp.setPanNo(employee.getPanNo());
			 emp.setPension(employee.getPension());
			 emp.setReligion(employee.getReligion());
			 emp.setScheme(employee.getScheme());
			 emp.setPromotionMacp(employee.getPromotionMacp());
			 emp.setIndividualPhoto(employee.getIndividualPhoto());
			 emp.setGroupPhoto(employee.getGroupPhoto());
		 }
		
		 return employeeDetailsRepo.save(emp);
	}


	@Override
	public Avaliableleave updateEmployeeLeave(Avaliableleave employee) {
			Avaliableleave avaliableleave = employeeLeaveRepo.findByEmpId(employee.getEmpId());
		
		 if (avaliableleave == null) {
			 throw new InvalidEmployeeIdException(employee);
		 }
		
		 else {
			 avaliableleave.setCcl(employee.getCcl());
			 avaliableleave.setCl(employee.getCl());
			 avaliableleave.setCommutedHpl(employee.getCommutedHpl());
			 avaliableleave.setEl(employee.getEl());
			 avaliableleave.setEolWithMc(employee.getEolWithMc());
			 avaliableleave.setEolWithoutMc(employee.getEolWithoutMc());
			 avaliableleave.setHpl(employee.getHpl());
			 avaliableleave.setMaternityLeave(employee.getMaternityLeave());
			 avaliableleave.setOtlCompOff(employee.getOtlCompOff());
			 avaliableleave.setPaternityLeave(employee.getPaternityLeave());
			 avaliableleave.setSslLeave(employee.getSslLeave());
			
			 
			
			 
		 }
		return  employeeLeaveRepo.save(avaliableleave);

		
	}

}
