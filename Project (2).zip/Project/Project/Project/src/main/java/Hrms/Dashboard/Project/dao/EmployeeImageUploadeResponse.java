package Hrms.Dashboard.Project.dao;

public class EmployeeImageUploadeResponse {
	
	 private Long id;
		
	    private String individualPhoto;
	
	    private String groupPhoto;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getIndividualPhoto() {
			return individualPhoto;
		}

		public void setIndividualPhoto(String individualPhoto) {
			this.individualPhoto = individualPhoto;
		}

		public String getGroupPhoto() {
			return groupPhoto;
		}

		public void setGroupPhoto(String groupPhoto) {
			this.groupPhoto = groupPhoto;
		}
	    
	    

}
