package Hrms.Dashboard.Project.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import java.util.Date;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "employee")
public class Employee {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name= "id")
	    private Long id;
	    
	    @Column(name= "emp_Id")
	    private String empId;
	    
	    @Column(name= "gender")
		private String gender ;

	    
	    @Column(name= "date_Of_Birth")
	    private Date dateOfBirth;
	    
	    
	    @Column(name= "employee_type")
	    private String employeeType;
	    
	    
	    @Column(name= "date_Of_Joining")
	    private Date dateOfJoining;
	    
	    @Column(name= "date_Of_Retirement")
	    private Date dateOfRetirement;
	    
	    @Column(name= "trade ")
	    private String trade;
	    
	    
	    @Column(name="job_type")
		private String jobType ;
	    
	    
	    @Column(name= "pension")
	    private String pension;
	    
	    @Column(name= "gpf_Ops_Nps_No ")
	    private String gpfOpsNpsNo;
	    
	    @Column(name= "pan_No ")
	    private String panNo;
	    
	    @Column(name= "aadhar_No ")
	    private Long  aadharNo;
	    
	    
	    @Column(name= "grade")
	    private String grade;
	    
	    
	    
	
	    @Column(name= "blood_group")
	    private String bloodGroup;
	    
	    
	 
	    @Column(name= "religion")
	    private String religion;
	    
	    @Column(name= "physically_Challenged ")
	    private Boolean physicallyChallenged;
	    
	    @Column(name= "Promotion_MACP ")
	    private String promotionMacp;
	    
	  
	    @Column(name= "category")
	    private String category;
	    
	  
	    @Column(name= "scheme" )
	    private String scheme;
	    
	    @Column(name= "remarks  ")
	    private String remarks;
	    
	    @Lob
	    @Column(name= "individual_Photo ")
	    private String individualPhoto;
	    
	    
	    @Lob
	    @Column(name= "group_Photo ")
	    private String groupPhoto;
	    
	  
	    @ManyToOne
	    @JoinColumn(name = "emp_Id", referencedColumnName = "emp_Id", insertable = false, updatable = false)
	    private User user;
	    
	    
	    @ManyToOne
	    @JoinColumn(name = "emp_Id", referencedColumnName = "emp_Id", insertable = false, updatable = false)
	    private ContactInformation contact;

		public Employee() {
			super();
		
		}


		public Employee(String fileName, String string, byte[] bs) {
			super();
			
		}


		public Employee(Long id, String empId, String gender, Date dateOfBirth, String employeeType, Date dateOfJoining,
				Date dateOfRetirement, String trade, String jobType, String pension, String gpfOpsNpsNo, String panNo,
				Long aadharNo, String grade, String bloodGroup, String religion, Boolean physicallyChallenged,
				String promotionMacp, String category, String scheme, String remarks, String individualPhoto,
				String groupPhoto, User user, ContactInformation contact) {
			super();
			this.id = id;
			this.empId = empId;
			this.gender = gender;
			this.dateOfBirth = dateOfBirth;
			this.employeeType = employeeType;
			this.dateOfJoining = dateOfJoining;
			this.dateOfRetirement = dateOfRetirement;
			this.trade = trade;
			this.jobType = jobType;
			this.pension = pension;
			this.gpfOpsNpsNo = gpfOpsNpsNo;
			this.panNo = panNo;
			this.aadharNo = aadharNo;
			this.grade = grade;
			this.bloodGroup = bloodGroup;
			this.religion = religion;
			this.physicallyChallenged = physicallyChallenged;
			this.promotionMacp = promotionMacp;
			this.category = category;
			this.scheme = scheme;
			this.remarks = remarks;
			this.individualPhoto = individualPhoto;
			this.groupPhoto = groupPhoto;
			this.user = user;
			this.contact = contact;
		}


		public Long getId() {
			return id;
		}


		public void setId(Long id) {
			this.id = id;
		}


		public String getEmpId() {
			return empId;
		}


		public void setEmpId(String empId) {
			this.empId = empId;
		}


		public String getGender() {
			return gender;
		}


		public void setGender(String gender) {
			this.gender = gender;
		}


		public Date getDateOfBirth() {
			return dateOfBirth;
		}


		public void setDateOfBirth(Date dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}


		public String getEmployeeType() {
			return employeeType;
		}


		public void setEmployeeType(String employeeType) {
			this.employeeType = employeeType;
		}


		public Date getDateOfJoining() {
			return dateOfJoining;
		}


		public void setDateOfJoining(Date dateOfJoining) {
			this.dateOfJoining = dateOfJoining;
		}


		public Date getDateOfRetirement() {
			return dateOfRetirement;
		}


		public void setDateOfRetirement(Date dateOfRetirement) {
			this.dateOfRetirement = dateOfRetirement;
		}


		public String getTrade() {
			return trade;
		}


		public void setTrade(String trade) {
			this.trade = trade;
		}


		public String getJobType() {
			return jobType;
		}


		public void setJobType(String jobType) {
			this.jobType = jobType;
		}


		public String getPension() {
			return pension;
		}


		public void setPension(String pension) {
			this.pension = pension;
		}


		public String getGpfOpsNpsNo() {
			return gpfOpsNpsNo;
		}


		public void setGpfOpsNpsNo(String gpfOpsNpsNo) {
			this.gpfOpsNpsNo = gpfOpsNpsNo;
		}


		public String getPanNo() {
			return panNo;
		}


		public void setPanNo(String panNo) {
			this.panNo = panNo;
		}


		public Long getAadharNo() {
			return aadharNo;
		}


		public void setAadharNo(Long aadharNo) {
			this.aadharNo = aadharNo;
		}


		public String getGrade() {
			return grade;
		}


		public void setGrade(String grade) {
			this.grade = grade;
		}


		public String getBloodGroup() {
			return bloodGroup;
		}


		public void setBloodGroup(String bloodGroup) {
			this.bloodGroup = bloodGroup;
		}


		public String getReligion() {
			return religion;
		}


		public void setReligion(String religion) {
			this.religion = religion;
		}


		public Boolean getPhysicallyChallenged() {
			return physicallyChallenged;
		}


		public void setPhysicallyChallenged(Boolean physicallyChallenged) {
			this.physicallyChallenged = physicallyChallenged;
		}


		public String getPromotionMacp() {
			return promotionMacp;
		}


		public void setPromotionMacp(String promotionMacp) {
			this.promotionMacp = promotionMacp;
		}


		public String getCategory() {
			return category;
		}


		public void setCategory(String category) {
			this.category = category;
		}


		public String getScheme() {
			return scheme;
		}


		public void setScheme(String scheme) {
			this.scheme = scheme;
		}


		public String getRemarks() {
			return remarks;
		}


		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}


		public String getIndividualPhoto() {
			return individualPhoto;
		}


		public void setIndividualPhoto(String individualPhoto) {
			this.individualPhoto = individualPhoto;
		}


		public String getGroupPhoto() {
			return groupPhoto;
		}


		public void setGroupPhoto(String groupPhoto) {
			this.groupPhoto = groupPhoto;
		}


		public User getUser() {
			return user;
		}


		public void setUser(User user) {
			this.user = user;
		}


		public ContactInformation getContact() {
			return contact;
		}


		public void setContact(ContactInformation contact) {
			this.contact = contact;
		}


		@Override
		public String toString() {
			return "Employee [id=" + id + ", empId=" + empId + ", gender=" + gender + ", dateOfBirth=" + dateOfBirth
					+ ", employeeType=" + employeeType + ", dateOfJoining=" + dateOfJoining + ", dateOfRetirement="
					+ dateOfRetirement + ", trade=" + trade + ", jobType=" + jobType + ", pension=" + pension
					+ ", gpfOpsNpsNo=" + gpfOpsNpsNo + ", panNo=" + panNo + ", aadharNo=" + aadharNo + ", grade="
					+ grade + ", bloodGroup=" + bloodGroup + ", religion=" + religion + ", physicallyChallenged="
					+ physicallyChallenged + ", promotionMacp=" + promotionMacp + ", category=" + category + ", scheme="
					+ scheme + ", remarks=" + remarks + ", individualPhoto=" + individualPhoto + ", groupPhoto="
					+ groupPhoto + ", user=" + user + ", contact=" + contact + "]";
		}


		

		


		

		

}