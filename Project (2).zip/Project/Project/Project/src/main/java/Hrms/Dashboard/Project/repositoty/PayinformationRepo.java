package Hrms.Dashboard.Project.repositoty;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Hrms.Dashboard.Project.model.Payinformation;

@Repository
public interface PayinformationRepo extends JpaRepository<Payinformation, Integer> {


}
