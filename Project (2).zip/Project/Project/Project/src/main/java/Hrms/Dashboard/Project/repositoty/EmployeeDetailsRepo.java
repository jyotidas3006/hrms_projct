package Hrms.Dashboard.Project.repositoty;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import Hrms.Dashboard.Project.model.ContactInformation;
import Hrms.Dashboard.Project.model.Employee;

@Repository
public interface EmployeeDetailsRepo  extends JpaRepository<Employee, Integer> {
	
	
	

	@Query(nativeQuery = true, value = "select emp.id , emp.emp_Id,\r\n"
			+ " emp.date_Of_Joining, emp.date_Of_Retirement,\r\n"
			+ " emp.gender ,\r\n"
			+ "cn.mobile_no ,\r\n"
			+ "cn.alternative_no,\r\n"
			+ "us.user_name\r\n"
			+ "FROM employee AS emp \r\n"
			+ "JOIN contactinformation as cn on emp.emp_Id = cn.emp_Id \r\n"
			+ "join  user as us on emp.emp_Id = us.emp_Id ")
	//@Query(nativeQuery = true , value ="select * from employee ")
	 public List<Employee> findAllEmployee();

	

	public Employee findByEmpId( String empId);
	
	
	
	
	
}
