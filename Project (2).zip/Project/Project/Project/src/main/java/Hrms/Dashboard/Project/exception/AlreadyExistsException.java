package Hrms.Dashboard.Project.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class AlreadyExistsException  extends RuntimeException{
	
	@SuppressWarnings("unused")
	private String empId;

	public AlreadyExistsException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AlreadyExistsException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AlreadyExistsException(String empId) {
		super(String.format( empId));
		this.empId = empId;
		
	}

	

	

	
}
