package Hrms.Dashboard.Project.dao;

public class AttendaceHistoryRequest {

}
