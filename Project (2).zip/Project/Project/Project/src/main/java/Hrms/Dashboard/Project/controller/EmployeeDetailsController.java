package Hrms.Dashboard.Project.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import Hrms.Dashboard.Project.dao.EmployeeListResponce;
import Hrms.Dashboard.Project.dao.PayinformationRequest;
import Hrms.Dashboard.Project.dao.PayinformationResponse;
import Hrms.Dashboard.Project.model.Avaliableleave;
import Hrms.Dashboard.Project.model.ContactInformation;
import Hrms.Dashboard.Project.model.Employee;
import Hrms.Dashboard.Project.repositoty.ContactInformationRepo;
import Hrms.Dashboard.Project.service.EmployeeDetailsInterface;


@RestController
@RequestMapping("/hrms/dashboard")
public class EmployeeDetailsController {
	
	@Autowired
	private EmployeeDetailsInterface employeeDetailsInterface;
	
	@PostMapping("/addEmployee/Details")
	public ResponseEntity<Employee>  addEmployeeDetails (@RequestBody Employee empRequest){
		Employee employee =employeeDetailsInterface.addEmpolyeeDetails(empRequest);
		return new ResponseEntity<Employee> (employee, HttpStatus.CREATED);
	}
	
	
	@GetMapping("/Employee/List")
	public List<EmployeeListResponce> getEmployeeDetails (){
		return  employeeDetailsInterface.getEmpolyeeList();
	
	}
	
	

	@PostMapping("/addEmployee/Leave")
	public ResponseEntity<Avaliableleave>  addEmployeeLeave (@RequestBody Avaliableleave  empRequest){
		Avaliableleave employee =employeeDetailsInterface.addEmployeeLeave(empRequest);
		return new ResponseEntity<Avaliableleave> (employee, HttpStatus.CREATED);
	}
	
	
	@PostMapping("/addEmployee/payment")
	public ResponseEntity<PayinformationResponse>  addEmployeepay (@RequestBody PayinformationRequest  empRequest){
		PayinformationResponse employee =employeeDetailsInterface.addEmployeepayment(empRequest);
		return new ResponseEntity<PayinformationResponse> (employee,HttpStatus.CREATED);
	}
	
	   
	@PostMapping("/addEmployee/Contact/information")
	public ResponseEntity<ContactInformation>  addEmployeeContactInformation (@RequestBody ContactInformation  empRequest){
		ContactInformation employee =employeeDetailsInterface.addEmpolyeeContactInformation(empRequest);
		return new ResponseEntity<ContactInformation> (employee,HttpStatus.CREATED);
	}
	
	@PostMapping("/upload/images")
	  public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile mfile) {
	    File file;
	    if (mfile.isEmpty() !=true ) {
	    	file = new File ("C://Users/Greenusys Technology/Desktop/images/"+mfile.getOriginalFilename());
	    	  try {
	     OutputStream os = new FileOutputStream(file);
	     os.write(mfile.getBytes());
	     os.close();
	      } catch (Exception e) {
	     e.printStackTrace();
	
	    }
	  }
	    
	    
	      return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body("FileUploaded");
}
	
	@PostMapping("/update/employee/details")
	public ResponseEntity<Employee> updateEmployeeDetails( @RequestBody Employee empRequest) {
		Employee employee = employeeDetailsInterface.updateEmployeeDetails(empRequest);
		return new ResponseEntity<Employee>(employee, HttpStatus.ACCEPTED);
		
		
		
	}
	
	@PostMapping("/update/employee/leave")
	public ResponseEntity<Avaliableleave> updateEmployeeLeave( @RequestBody Avaliableleave employee) {
		Avaliableleave avaliableleave = employeeDetailsInterface.updateEmployeeLeave(employee);
		return new ResponseEntity<Avaliableleave>(avaliableleave, HttpStatus.ACCEPTED);
		}
	
}