package Hrms.Dashboard.Project.dao;

public class SectionInchargeResponse {
	
	  private String emp_id;
	  private String  sectionincharge_Name;

	public String getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}

	public String getSectionincharge_Name() {
		return sectionincharge_Name;
	}

	public void setSectionincharge_Name(String sectionincharge_Name) {
		this.sectionincharge_Name = sectionincharge_Name;
	}
	  
	  
	

}
