package Hrms.Dashboard.Project.model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import Hrms.Dashboard.Project.dao.AttendaceHistoryResponse;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "attendace_history")
public class AttendaceHistory {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "emp_Id")
    private String empId;

    @Column(name = "check_in_date")
    private LocalDate checkInDate;
    

    @Column(name = "check_in_time")
    private LocalTime  checkInTime;

    @Column(name = "check_out_time")
    private LocalTime  checkOutTime;

    @Column(name = "working_hours")
    private Integer workingHours;

    @Column(name = "working_minutes")
    private Integer workingMinutes;
    
    @Column(name = "attendance_status")
    private String attendanceStatus;

    @ManyToOne
    @JoinColumn(name = "emp_Id", referencedColumnName = "emp_Id", insertable = false, updatable = false)
    private User user;
    
    
    @ManyToOne
    @JoinColumn(name = "emp_Id", referencedColumnName = "emp_Id", insertable = false, updatable = false)
    private Employee emp;


		public AttendaceHistory() {
			super();
			
		}


		public AttendaceHistory(Long id, String empId, LocalDate checkInDate, LocalTime checkInTime,
				LocalTime checkOutTime, Integer workingHours, Integer workingMinutes, String attendanceStatus,
				User user, Employee emp) {
			super();
			this.id = id;
			this.empId = empId;
			this.checkInDate = checkInDate;
			this.checkInTime = checkInTime;
			this.checkOutTime = checkOutTime;
			this.workingHours = workingHours;
			this.workingMinutes = workingMinutes;
			this.attendanceStatus = attendanceStatus;
			this.user = user;
			this.emp = emp;
		}


		public Long getId() {
			return id;
		}


		public void setId(Long id) {
			this.id = id;
		}


		public String getEmpId() {
			return empId;
		}


		public void setEmpId(String empId) {
			this.empId = empId;
		}


		public LocalDate getCheckInDate() {
			return checkInDate;
		}


		public void setCheckInDate(LocalDate checkInDate) {
			this.checkInDate = checkInDate;
		}


		public LocalTime getCheckInTime() {
			return checkInTime;
		}


		public void setCheckInTime(LocalTime checkInTime) {
			this.checkInTime = checkInTime;
		}


		public LocalTime getCheckOutTime() {
			return checkOutTime;
		}


		public void setCheckOutTime(LocalTime checkOutTime) {
			this.checkOutTime = checkOutTime;
		}


		public Integer getWorkingHours() {
			return workingHours;
		}


		public void setWorkingHours(Integer workingHours) {
			this.workingHours = workingHours;
		}


		public Integer getWorkingMinutes() {
			return workingMinutes;
		}


		public void setWorkingMinutes(Integer workingMinutes) {
			this.workingMinutes = workingMinutes;
		}


		public String getAttendanceStatus() {
			return attendanceStatus;
		}


		public void setAttendanceStatus(String attendanceStatus) {
			this.attendanceStatus = attendanceStatus;
		}


		public User getUser() {
			return user;
		}


		public void setUser(User user) {
			this.user = user;
		}


		public Employee getEmp() {
			return emp;
		}


		public void setEmp(Employee emp) {
			this.emp = emp;
		}


		@Override
		public String toString() {
			return "AttendaceHistory [id=" + id + ", empId=" + empId + ", checkInDate=" + checkInDate + ", checkInTime="
					+ checkInTime + ", checkOutTime=" + checkOutTime + ", workingHours=" + workingHours
					+ ", workingMinutes=" + workingMinutes + ", attendanceStatus=" + attendanceStatus + ", user=" + user
					+ ", emp=" + emp + "]";
		}


		public List<AttendaceHistoryResponse> getAttendanceRecords() {
			// TODO Auto-generated method stub
			return null;
		}
		
		
		

	
}
