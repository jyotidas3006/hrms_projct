package Hrms.Dashboard.Project.dao;

public class PayinformationResponse {
	
	private Long payinformationId;
	 
	   
    private Long basicPay;
 
   
    private Long taDa;
    
   
    private Long hra;
    
     
    private Long tpt;
    
    
    private Long  persPay;
    
     
    private Long govtPerks;
    
   
    private String empId;

    private Double totalPay;

	public Long getPayinformationId() {
		return payinformationId;
	}

	public void setPayinformationId(Long payinformationId) {
		this.payinformationId = payinformationId;
	}

	public Long getBasicPay() {
		return basicPay;
	}

	public void setBasicPay(Long basicPay) {
		this.basicPay = basicPay;
	}

	public Long getTaDa() {
		return taDa;
	}

	public void setTaDa(Long taDa) {
		this.taDa = taDa;
	}

	public Long getHra() {
		return hra;
	}

	public void setHra(Long hra) {
		this.hra = hra;
	}

	public Long getTpt() {
		return tpt;
	}

	public void setTpt(Long tpt) {
		this.tpt = tpt;
	}

	public Long getPersPay() {
		return persPay;
	}

	public void setPersPay(Long persPay) {
		this.persPay = persPay;
	}

	public Long getGovtPerks() {
		return govtPerks;
	}

	public void setGovtPerks(Long govtPerks) {
		this.govtPerks = govtPerks;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public Double getTotalPay() {
		return totalPay;
	}

	public void setTotalPay(Double totalPay) {
		this.totalPay = totalPay;
	}
    
    

}
