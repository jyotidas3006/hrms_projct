package Hrms.Dashboard.Project.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "sectionincharge")
public class SectionIncharge {

	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name="sectionincharge_id") 
	    private Long sectionincharge_id;
	    
	    @Column(name="emp_Id")  
	    private String empId;
	    
	    @Column(name="sectionincharge_name")
	    private String  sectionincharge_Name ;
	 
	    @Column(name="password")
	    private String password;
	 
	    @Column(name="roles")
	    private String roles;
	   
	   @ManyToOne
	    @JoinColumn(name = "emp_Id", referencedColumnName = "emp_Id", insertable = false, updatable = false)
	    private User user;

	public SectionIncharge() {
		super();
	
	}

	

	public SectionIncharge(Long sectionincharge_id, String empId, String sectionincharge_Name, String password,
			String roles, User user) {
		super();
		this.sectionincharge_id = sectionincharge_id;
		this.empId = empId;
		this.sectionincharge_Name = sectionincharge_Name;
		this.password = password;
		this.roles = roles;
		this.user = user;
	}



	public Long getSectionincharge_id() {
		return sectionincharge_id;
	}

	public void setSectionincharge_id(Long sectionincharge_id) {
		this.sectionincharge_id = sectionincharge_id;
	}

	
	public String getEmpId() {
		return empId;
	}



	public void setEmpId(String empId) {
		this.empId = empId;
	}



	public String getSectionincharge_Name() {
		return sectionincharge_Name;
	}

	public void setSectionincharge_Name(String sectionincharge_Name) {
		this.sectionincharge_Name = sectionincharge_Name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "SectionIncharge [sectionincharge_id=" + sectionincharge_id + ", emp_id=" + empId
				+ ", sectionincharge_Name=" + sectionincharge_Name + ", password=" + password + ", roles=" + roles
				+ ", user=" + user + "]";
	}

	
	  
	
	   }
