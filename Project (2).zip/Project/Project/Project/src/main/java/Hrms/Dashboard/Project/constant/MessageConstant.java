package Hrms.Dashboard.Project.constant;

public class MessageConstant {
	
		public static final String SUCCESS = "SUCCESS";

		public static final String DATA_NOT_FOUND = "Data not found";

		public static final String ALREADY_EXISTS = "ALREADY_EXISTS";
		
		public static final String INVALID_EMPID = "INVALID_EMPID";

		public static final String INVALID_DATA = "INVALID_DATA";
		
		public static final String HEADER_STRING = "Authorization";
		
		public static final String INVALID_DATA_FOR_UPDATE = "Invalid data for update.";

		public static final String INVALID_CUSTOMER = " Invalid customer mail.";

		public static final String INVALID_PASSWORD = "Invalid  password.";

		public static final String Insufficient_Balance = "Insufficient Balance";
		
		public static final String ENTER_YOUR_DETAIL = "Enter your Details. ";
		
		public static final String INVALID_CREDENTIALS = "INVALID_CREDENTIALS";
		
		public static final String CUSTOMER_EMAIL_INVALID = "Customer email invalid";
		
		public static final String PLEASE_ENTER_CONFIRMPASSWORD = "Please enter confirmpassword";
		
		public static final String PASSWORDS_DO_NOT_MATCH = "Passwords do not match, please retype.";
		
		public static final String ENTER_YOUR_EMAIL = "Please enter your email";
		
		public static final String CUSTOMER_EMAIL_ALREADY_EXIT = "CUSTOMER EMAIL ID ALREADY EXIST.";
		
		public static final String CUSTOMER_ADDRESS_DOES_NOT_EXIST = "Customer's Address does not Exist";
		
		public static final String CUSTOMER_ADDRESS__ID_DOES_NOT_EXIST = "Customer Address ID does not Exist";
		
		public static final String FIELD_NOT_NULL = "Please enter mandatory fiells.";
		
		public static final String YOUR_ARE_CHECKOUT_SUCCESSFULLY = "you are check out sucessfully";
		
		public static final String Please_fullfilled_All_MANDATORY_fiellds = "Please enter All mandatory fiellds.";
		
		public static final String Please_fullfilled_All_fiellds = "Please enter All fiellds.";
		
		public static final String CUSTOMER_ADDRESSID_CAN_NOT_NULL = "CustomerAddressId can not empty.";
		
		public static final String CUSTOMER_ID_CAN_NOT_NULL = "CustomerId can not empty.";
		
		public static final String CUSTOMERId_DOES_NOT_EXIST = "CustomerId does not Exist";
		
		public static final String ENTER_CUSTOMERId = "Please enter your CustomerId";
		
		public static final String MOBILE_ALREADY_EXIST_ENTER_ANOTHER_NUMBER = "MobileNumber already exist. Please enter another MobileNumber.";
		
		public static final String EMAIL_ALREADY_EXIST_ENTER_ANOTHER_EMAIL = "Email already exist. Please enter another Email.";
		
		public static final String EMPLOYEE_ID_ALREADY_EXIST_ENTER_ANOTHER_EMPLOYEE_ID = "Employee Id already exist. Please enter another Employee Id.";
		public static final String INVALID_COUPON = "Invalid coupon.";
		
		public static final String CANNOT_ADD_DATA = "cannot add data.";
		
		
		public static final String PASSWORD_CHANGED_SUCCESSFULLY = "passwrd changed successfully";
		
		public static final String CUSTOMERORDER_DOES_NOT_EXIST = "CustomerOrder does not exist";
		
		
		public static final String USER_EMAIL_NOT_FOUND = "Email not find with this user";
		
		public static final String PASSWORD_CANNOT_NULL = "password cannot be null";
		
		public static final String USER_NOT_FOUND = "User does not Exist";
		
		public static final String ROLE_NOT_FOUND = "User role does not Exist";
		
		public static final String SECTION_INCHARGE_NOT_FOUND = "Section incharge does not Exist";

		public static final String MAIL_SENT_SUCCESSFULLY = " Mail send suceessfully";

		public static final String INVALID_OTP = "invalid OTP";

		public static final String USER_DOES_NOT_EXIST="user does not exit.";
		
	    public static final String ORDERITEM_DOES_NOT_EXIST="OrderItem does not exit.";
	}



