package Hrms.Dashboard.Project.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "contactinformation")
public class ContactInformation {

	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name= "contactinformation_id")
	    private Long contactinformationId;
	    
	    @Column(name= "mobile_no")
	    private String mobileNo;
	    
	    @Column(name= "alternative_no")
	    private String alternativeNo;
	    
	    @Column(name="emp_Id")  
	    private String empId;
	  
	    @Column(name= "temporary_address")
	    private String temporaryAddress;
	    
	    @Column(name= "permanent_address ")
	    private String permanentAddress;
	    
	   
	    
	    @Column(name= "marriage_status")
	    private String marriageStatus;
	    
	    

		public ContactInformation() {
			super();
			
		}

		




		public ContactInformation(Long contactinformationId, String mobileNo, String alternativeNo, String empId,
				String temporaryAddress, String permanentAddress, String marriageStatus) {
			super();
			this.contactinformationId = contactinformationId;
			this.mobileNo = mobileNo;
			this.alternativeNo = alternativeNo;
			this.empId = empId;
			this.temporaryAddress = temporaryAddress;
			this.permanentAddress = permanentAddress;
			this.marriageStatus = marriageStatus;
		}






		public Long getContactinformationId() {
			return contactinformationId;
		}

		public void setContactinformationId(Long contactinformationId) {
			this.contactinformationId = contactinformationId;
		}


		public String getMobileNo() {
			return mobileNo;
		}
         
		public String getEmpId() {
			return empId;
		}

		public void setEmpId(String empId) {
			this.empId = empId;
		}
		
		public void setMobileNo(String mobileNo) {
			this.mobileNo = mobileNo;
		}

		public String getAlternativeNo() {
			return alternativeNo;
		}

		public void setAlternativeNo(String alternativeNo) {
			this.alternativeNo = alternativeNo;
		}

		public String getTemporaryAddress() {
			return temporaryAddress;
		}

		public void setTemporaryAddress(String temporaryAddress) {
			this.temporaryAddress = temporaryAddress;
		}

		public String getPermanentAddress() {
			return permanentAddress;
		}

		public void setPermanentAddress(String permanentAddress) {
			this.permanentAddress = permanentAddress;
		}


		



		public String getMarriageStatus() {
			return marriageStatus;
		}






		public void setMarriageStatus(String marriageStatus) {
			this.marriageStatus = marriageStatus;
		}






		@Override
		public String toString() {
			return "ContactInformation [contactinformationId=" + contactinformationId + ", mobileNo=" + mobileNo
					+ ", alternativeNo=" + alternativeNo + ", empId=" + empId + ", temporaryAddress=" + temporaryAddress
					+ ", permanentAddress=" + permanentAddress + ", marriageStatus=" + marriageStatus + "]";
		}

		



		

		

		
}
