package Hrms.Dashboard.Project.dao;

public class UserLoginRequest {
	
	  private String empId;		
	  private String hashPassword;
	  public UserLoginRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getHashPassword() {
		return hashPassword;
	}
	public void setHashPassword(String hashPassword) {
		this.hashPassword = hashPassword;
	}
	
	
		

}
