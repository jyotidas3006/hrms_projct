//package Hrms.Dashboard.Project.repositoty;
//
//import java.util.List;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import Hrms.Dashboard.Project.model.TrnUserToken;
//
//public interface UserTokenRepository extends JpaRepository<TrnUserToken, Integer> {
//
//	List<TrnUserToken> findByTokenAndIsActive(String token, boolean b);
//
//}
