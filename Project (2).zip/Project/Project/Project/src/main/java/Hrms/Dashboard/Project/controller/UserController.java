package Hrms.Dashboard.Project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//import Hrms.Dashboard.Project.dao.ResponseEntity;
import Hrms.Dashboard.Project.dao.UserDto;
import Hrms.Dashboard.Project.dao.UserEmployeeIDResponse;
import Hrms.Dashboard.Project.dao.UserLogInResponse;
import Hrms.Dashboard.Project.dao.UserLoginRequest;
import Hrms.Dashboard.Project.dao.UserRequest;
import Hrms.Dashboard.Project.dao.UserResponse;
import Hrms.Dashboard.Project.model.User;
import Hrms.Dashboard.Project.service.UserInterface;


@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	 private UserInterface userInterface;
	
	
	@GetMapping("/")
	public String Home() {
		return "index";
		
	}
	
	@PostMapping("/signup")
	public ResponseEntity<String> createNewUser(@RequestBody UserRequest request) throws Exception {
	    UserResponse userResponse = userInterface.ceateNewUser(request);
	    return ResponseEntity.status(HttpStatus.CREATED)
	            .body("Employee registered successfully" );
	}

	
	@GetMapping("/list")
	public  List<UserResponse>  getUserList(){
		return userInterface.getUserList();  
		
		
	}
	
	@PostMapping("/update")
	public ResponseEntity<User> updateUser( @RequestBody User request) {
		User user =userInterface.updateUser(request);
		return new ResponseEntity<User> (user , HttpStatus.ACCEPTED);
		
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<UserLogInResponse> userLogIn(@RequestBody UserLoginRequest request) throws Exception {
	    UserLogInResponse user = userInterface.userLogIn(request);
	    return new ResponseEntity<>(user, HttpStatus.OK);
	}

	
	 @GetMapping("/loginPage")
	    public String showLoginPage() {
	        return "login";
	    }

	   

	    
	    @GetMapping("/EmpIdList")
	    public List<UserEmployeeIDResponse> getUserEmployeeIdList(){
			return userInterface.getUserEmployeeIdList();
	    	
	    }
}
