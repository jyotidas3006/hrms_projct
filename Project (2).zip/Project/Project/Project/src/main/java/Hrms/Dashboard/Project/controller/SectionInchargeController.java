package Hrms.Dashboard.Project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import Hrms.Dashboard.Project.dao.SectionInchargeResponse;
import Hrms.Dashboard.Project.model.SectionIncharge;
import Hrms.Dashboard.Project.service.SectionInchargeInterface;

@RestController
@RequestMapping("/hrms/sectionincharge")
public class SectionInchargeController {
	
	 @Autowired
	  private SectionInchargeInterface sectionInchargeInterface;
	
	
	@PostMapping("/add")
	public SectionIncharge addSectionIncharge(@RequestBody SectionIncharge request) {
		return sectionInchargeInterface.addSectionIncharge(request);
		
	}
	
	@GetMapping("/incharge")
	public List<SectionInchargeResponse> getSectionIncharge(){
		return sectionInchargeInterface.getSectionIncharge();
		
	}
	
	
	@PutMapping("/update")
	public ResponseEntity<String> updateSectionIncharge(@RequestBody SectionIncharge request) {
	    SectionIncharge updatedSectionIncharge = sectionInchargeInterface.updateSectionIncharge(request);
	    return ResponseEntity.status(HttpStatus.OK).body("Successfully updated section incharge with ID: " + updatedSectionIncharge.getEmpId());
	}
	
	
	@DeleteMapping("/delete")
	public ResponseEntity<String> deleteSectionIncharge(@RequestParam String empId) {
	    sectionInchargeInterface.deleteSectionIncharge(empId);
	    return ResponseEntity.status(HttpStatus.OK).body("Successfully deleted section incharge.");
	}

}
