package Hrms.Dashboard.Project.repositoty;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import Hrms.Dashboard.Project.model.ContactInformation;
import Hrms.Dashboard.Project.model.Employee;
import jakarta.persistence.Column;

@Repository
public interface ContactInformationRepo extends JpaRepository<ContactInformation, Integer>{
	

}
