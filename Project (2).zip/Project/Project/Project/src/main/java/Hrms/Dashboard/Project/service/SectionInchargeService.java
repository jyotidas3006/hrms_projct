package Hrms.Dashboard.Project.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import Hrms.Dashboard.Project.dao.SectionInchargeResponse;
import Hrms.Dashboard.Project.exception.NotFoundException;
import Hrms.Dashboard.Project.model.SectionIncharge;
import Hrms.Dashboard.Project.repositoty.SectionInchargeRepo;

@Service
public class SectionInchargeService  implements SectionInchargeInterface {
	
	@Autowired
	 private SectionInchargeRepo sectionInchargeRepo;

	
	@Override
	public SectionIncharge addSectionIncharge(SectionIncharge request) {
		
		return sectionInchargeRepo.save(request);
	}


	@Override
	public List<SectionInchargeResponse> getSectionIncharge() {
	    return sectionInchargeRepo.findAll().stream()
	            .map(incharge -> {
	                SectionInchargeResponse response = new SectionInchargeResponse();
	                response.setEmp_id(incharge.getEmpId());
	                response.setSectionincharge_Name(incharge.getSectionincharge_Name());
	                return response;
	            })
	            .collect(Collectors.toList());
	}


	@Override
	public SectionIncharge updateSectionIncharge(SectionIncharge request) {
		
		SectionIncharge response = sectionInchargeRepo.findByEmpId(request.getEmpId());
		
		if (ObjectUtils.isEmpty(response)) {
			 throw new NotFoundException("Section Incharge Not Found");
		}
		
		else {
			
			response.setPassword(request.getPassword());
			response.setRoles(request.getRoles());
			sectionInchargeRepo.save(response);
			
		}
		return response;
	}


	@Override
	public void deleteSectionIncharge(String empId) {
	    SectionIncharge sectionIncharge = sectionInchargeRepo.findSectionInchargeByEmpId(empId);
	    
	    if (sectionIncharge == null) {
	        throw new NotFoundException("Section Incharge Not Found");
	    }
	    
	    sectionInchargeRepo.delete(sectionIncharge);
	}


	

}
