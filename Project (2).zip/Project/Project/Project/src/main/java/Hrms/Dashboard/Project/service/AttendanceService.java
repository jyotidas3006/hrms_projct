package Hrms.Dashboard.Project.service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import Hrms.Dashboard.Project.dao.AttendaceHistoryResponse;
import Hrms.Dashboard.Project.dao.CheckInResponse;
import Hrms.Dashboard.Project.dao.CheckOutResponse;
import Hrms.Dashboard.Project.dao.ChekInRequest;
import Hrms.Dashboard.Project.exception.AlreadyExistsException;
import Hrms.Dashboard.Project.model.AttendaceHistory;
import Hrms.Dashboard.Project.model.Employee;
import Hrms.Dashboard.Project.model.User;
import Hrms.Dashboard.Project.repositoty.AttendaceHistoryRepo;

@Service
public class AttendanceService  implements AttendanceInterface{
	
	
	
	@Autowired
	private AttendaceHistoryRepo attendaceHistoryRepo;
	
	


	

	@Override
	public CheckInResponse addAttendanceLogIn(ChekInRequest checkIn) throws Exception {
	    LocalTime checkInTime = LocalTime.now();
	    LocalDate currentDate = LocalDate.now();
	    
	    LocalDateTime currentDateTime = LocalDateTime.of(currentDate, checkInTime); 
	    
	    AttendaceHistory attendanceHistory = attendaceHistoryRepo.findLatestByEmpIdAndDate(checkIn.getEmpId(), currentDate);
	    if (attendanceHistory != null) {
	        throw new AlreadyExistsException("Attendance already recorded for today.");
	    }

	    AttendaceHistory attendanceRecord = new AttendaceHistory();
	    attendanceRecord.setEmpId(checkIn.getEmpId());
	    attendanceRecord.setCheckInTime(checkInTime);
	    attendanceRecord.setCheckInDate(currentDate); 
	    attendanceRecord.setWorkingHours(0);
	    attendanceRecord.setWorkingMinutes(0);
	   
	    AttendaceHistory savedAttendanceRecord = attendaceHistoryRepo.save(attendanceRecord);

	    CheckInResponse checkInResponse = new CheckInResponse();
	    BeanUtils.copyProperties(savedAttendanceRecord, checkInResponse);

	    return checkInResponse;
	}


	
	

	@Override
	public CheckOutResponse attendanceCheckOut(String empId) {
	    LocalTime checkOutTime = LocalTime.now();
	    LocalDate currentDate = LocalDate.now();
	    LocalDateTime currentDateTime = LocalDateTime.of(currentDate, checkOutTime); 

	    AttendaceHistory attendanceHistory = attendaceHistoryRepo.findLatestByEmpIdAndDate(empId, currentDate);
	    
	    if (attendanceHistory == null) {
	        throw new AlreadyExistsException("No attendance recorded for today. Cannot check out.");
	    }

	    if (attendanceHistory.getCheckOutTime() != null) {
	        throw new AlreadyExistsException("Attendance already checked out for today.");
	    }

	    Duration duration = Duration.between(attendanceHistory.getCheckInTime(), currentDateTime.toLocalTime());
	    int workingHours = (int) duration.toHours();
	    int workingMinutes = (int) duration.toMinutesPart();

	    attendanceHistory.setCheckOutTime(checkOutTime);
	    attendanceHistory.setWorkingHours(workingHours);
	    attendanceHistory.setWorkingMinutes(workingMinutes);
	    attendanceHistory.setAttendanceStatus("Present");

	    if (checkOutTime.isBefore(LocalTime.of(6, 0))) { 
	        LocalDate previousDate = currentDate.minusDays(1);
	        AttendaceHistory previousAttendanceHistory = attendaceHistoryRepo.findByDate(previousDate);
	        if (previousAttendanceHistory != null) {
	            previousAttendanceHistory.setAttendanceStatus("Present");
	            attendaceHistoryRepo.save(previousAttendanceHistory);
	        }
	    }

	    AttendaceHistory savedHistory = attendaceHistoryRepo.save(attendanceHistory);

	    CheckOutResponse historyResponse = new CheckOutResponse();
	    BeanUtils.copyProperties(savedHistory, historyResponse);

	    return historyResponse;
	}




	@Override
	public List<AttendaceHistoryResponse> getAllAttendanceList() {
	    LocalDate currentDate = LocalDate.now();

	    List<AttendaceHistoryResponse> responseList = attendaceHistoryRepo.findAllActiveUser()
	            .stream()
	            .filter(history -> history.getCheckInDate().isEqual(currentDate)) 
	            .filter(history -> "Present".equals(history.getAttendanceStatus())) 
	            .map(history -> {
	                AttendaceHistoryResponse response = new AttendaceHistoryResponse();
	                Employee emp = history.getEmp();
	                User user = history.getUser();

	                response.setEmpId(history.getEmpId());
	                response.setUserName(user != null ? user.getUserName() : "User not available");
	                response.setCheckInDate(history.getCheckInDate());
	                response.setCheckInTime(history.getCheckInTime());
	                response.setCheckOutTime(history.getCheckOutTime());
	                response.setWorkingHours(history.getWorkingHours());
	                response.setWorkingMinutes(history.getWorkingMinutes());
	                response.setAttendanceStatus(history.getAttendanceStatus());
	                response.setTrade(emp != null ? emp.getTrade() : "Trade not available");

	                return response;
	            })
	            .collect(Collectors.toList());

	    return responseList;
	}



	@Override
	public List<AttendaceHistoryResponse> trackAttendance(int year, int month) {
	    List<AttendaceHistoryResponse> responseList = new ArrayList<>();
	    YearMonth targetYearMonth = YearMonth.of(year, month);

	    List<AttendaceHistory> historyList = attendaceHistoryRepo.findAllActiveUser();

	    for (AttendaceHistory history : historyList) {
	        LocalDate checkInDate = history.getCheckInDate();
	        YearMonth attendanceYearMonth = YearMonth.from(checkInDate);

	        if (attendanceYearMonth.equals(targetYearMonth)) {
	          
	            AttendaceHistoryResponse response = createResponseFromHistory(history);
	         
	            if (history.getCheckOutTime() != null) {
	                response.setAttendanceStatus("P");
	            } else {
	                response.setAttendanceStatus("A"); 
	            }
	            responseList.add(response);
	        }
	    }

	    return responseList;
	}


	private AttendaceHistoryResponse createResponseFromHistory(AttendaceHistory history) {
	        AttendaceHistoryResponse response = new AttendaceHistoryResponse();
	        User user = history.getUser();
	        Employee emp = history.getEmp();

	        response.setEmpId(history.getEmpId());
	        response.setUserName(user.getUserName());
	        response.setCheckInDate(history.getCheckInDate());
	        response.setCheckInTime(history.getCheckInTime());
	        response.setCheckOutTime(history.getCheckOutTime());
	        response.setWorkingHours(history.getWorkingHours());
	        response.setWorkingMinutes(history.getWorkingMinutes());
	        response.setTrade(emp.getTrade());
	        response.setAttendanceStatus(history.getAttendanceStatus());
	        
	        response.setAttendanceStatus(history.getCheckOutTime() != null ? "P" : "A");

	        return response;
	    }




	@Override
	public AttendaceHistory getByEmployeeId(String empId) {
	    // Retrieve attendance history
	    AttendaceHistory attendanceHistory = attendaceHistoryRepo.findById(empId);

	    // Retrieve attendance dates for the employee
	    List<LocalDate> attendanceDates = attendaceHistoryRepo.findAttendanceDatesByEmployeeId(empId);

	    // Define a custom comparator for LocalDate objects
	    Comparator<LocalDate> localDateComparator = Comparator.naturalOrder();

	    // Find start and end dates
	    LocalDate startDate = attendanceDates.isEmpty() ? LocalDate.now() :
	            attendanceDates.stream().min(localDateComparator).orElse(LocalDate.now());
	    LocalDate endDate = attendanceDates.isEmpty() ? LocalDate.now() :
	            attendanceDates.stream().max(localDateComparator).orElse(LocalDate.now());

	    // Cache attendance dates
	    Set<LocalDate> attendanceDateSet = new HashSet<>(attendanceDates);

	    // Iterate through each date between start and end dates
	    for (LocalDate date = startDate; !date.isAfter(endDate); date = date.plusDays(1)) {
	        // If the date is not in the attendance dates, add an absent record
	        if (!attendanceDateSet.contains(date)) {
	            AttendaceHistory absentRecord = new AttendaceHistory();
	            absentRecord.setEmpId(empId);
	            absentRecord.setAttendanceStatus("Absent");
	            absentRecord.setCheckInDate(date);
	            attendaceHistoryRepo.save(absentRecord);
	        }
	    }

	    // Return the attendance history
	    return attendanceHistory;
	}


	}

