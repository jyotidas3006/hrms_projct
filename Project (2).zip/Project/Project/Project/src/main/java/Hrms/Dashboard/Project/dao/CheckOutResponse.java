package Hrms.Dashboard.Project.dao;

import java.time.LocalDateTime;
import java.util.Date;

public class CheckOutResponse {
	
	   private String empId;
	   private LocalDateTime checkOutTime;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public LocalDateTime getCheckOutTime() {
		return checkOutTime;
	}
	public void setCheckOutTime(LocalDateTime checkOutTime) {
		this.checkOutTime = checkOutTime;
	}
	   
	   
	   
	   
	   
	
	   
	   

}
