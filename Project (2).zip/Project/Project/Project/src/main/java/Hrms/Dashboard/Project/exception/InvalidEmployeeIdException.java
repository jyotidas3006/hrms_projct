package Hrms.Dashboard.Project.exception;

import Hrms.Dashboard.Project.model.Avaliableleave;
import Hrms.Dashboard.Project.model.Employee;
import Hrms.Dashboard.Project.model.User;

@SuppressWarnings("serial")
public class InvalidEmployeeIdException extends RuntimeException{
	
	 @SuppressWarnings("unused")
	private String empId;

		public InvalidEmployeeIdException( Employee employee) {
		super (String.format("Employee Id Not Found %s", employee.getEmpId()));
		
}

	public InvalidEmployeeIdException( User user) {
		super (String.format("Employee Id Not Found %s", user.getEmpId()));
		
}

	public InvalidEmployeeIdException(String user, String dataNotFound) {
	
	}
	

	public InvalidEmployeeIdException(Avaliableleave employee) {
		// TODO Auto-generated constructor stub
		super (String.format("Employee Id Not Found %s", employee.getEmpId()));
	}

	public InvalidEmployeeIdException(String empId) {
		super();
		this.empId = empId;
	}

	
	
	
}
