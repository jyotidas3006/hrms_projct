package Hrms.Dashboard.Project.dao;

public class UserEmployeeIDResponse{

	private String empId;
	
	private String userName;

	public UserEmployeeIDResponse() {
		// TODO Auto-generated constructor stub
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	
}
