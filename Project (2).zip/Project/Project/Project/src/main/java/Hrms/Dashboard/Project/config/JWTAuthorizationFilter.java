//package Hrms.Dashboard.Project.config;
//
//import java.io.IOException;
//
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
//
//import Hrms.Dashboard.Project.constant.MessageConstant;
////import jakarta.servlet.FilterChain;
//import jakarta.servlet.ServletException;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//
//public class JWTAuthorizationFilter extends BasicAuthenticationFilter {
//
//	public JWTAuthorizationFilter(AuthenticationManager authenticationManager) {
//		super(authenticationManager);
//		
//	}
//	
//	
//	@Override
//	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
//			throws IOException, ServletException {
//		 String header = request.getHeader(MessageConstant.HEADER_STRING);
//	}
//
//}
