package Hrms.Dashboard.Project.repositoty;

import java.lang.annotation.Native;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import Hrms.Dashboard.Project.model.SectionIncharge;
import Hrms.Dashboard.Project.model.User;

@Repository
public interface SectionInchargeRepo extends JpaRepository<SectionIncharge, Integer>{

	 
	  public SectionIncharge findByEmpId(String empId);
	  
	  
	  @Query(nativeQuery = true, value = "SELECT * FROM sectionincharge us WHERE us.emp_Id = :empId")
	  public SectionIncharge findSectionInchargeByEmpId(@Param("empId") String empId);

	

}
