package Hrms.Dashboard.Project.dao;

import java.util.Date;




public class EmployeeListResponce {
	

	   
	    private String empId;
	  
	    private String empName;
	    
	    
	    private String gender ;
	    
	   
	    private Date dateOfJoining;
	    
	  
	    private Date dateOfRetirement;
	    
	    private String mobileNo;
	    
	    
	    private String alternativeNo;


		public String getEmpId() {
			return empId;
		}


		public void setEmpId(String empId) {
			this.empId = empId;
		}


		public String getEmpName() {
			return empName;
		}


		public void setEmpName(String empName) {
			this.empName = empName;
		}


		


		public String getGender() {
			return gender;
		}


		public void setGender(String gender) {
			this.gender = gender;
		}


		public Date getDateOfJoining() {
			return dateOfJoining;
		}


		public void setDateOfJoining(Date dateOfJoining) {
			this.dateOfJoining = dateOfJoining;
		}


		public Date getDateOfRetirement() {
			return dateOfRetirement;
		}


		public void setDateOfRetirement(Date dateOfRetirement) {
			this.dateOfRetirement = dateOfRetirement;
		}


		public String getMobileNo() {
			return mobileNo;
		}


		public void setMobileNo(String mobileNo) {
			this.mobileNo = mobileNo;
		}


		public String getAlternativeNo() {
			return alternativeNo;
		}


		public void setAlternativeNo(String alternativeNo) {
			this.alternativeNo = alternativeNo;
		}
	    
	    
	    	

	  

}
