package Hrms.Dashboard.Project.exception;

public class FileUploadException extends RuntimeException{

}
