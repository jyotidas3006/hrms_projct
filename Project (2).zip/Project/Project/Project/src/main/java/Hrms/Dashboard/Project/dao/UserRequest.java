package Hrms.Dashboard.Project.dao;

public class UserRequest {
	
	
private String empId;						
	
	private String userName;
	
	private String userEmail;
	
	private String userRoles;
	
	private String sectionIncharge;
	
	private String hashPassword;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}

	public String getSectionIncharge() {
		return sectionIncharge;
	}

	public void setSectionIncharge(String sectionIncharge) {
		this.sectionIncharge = sectionIncharge;
	}

	public String getHashPassword() {
		return hashPassword;
	}

	public void setHashPassword(String hashPassword) {
		this.hashPassword = hashPassword;
	}
	
	

}
