package Hrms.Dashboard.Project.exception;


import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GloableExceptionHandler {

	@ExceptionHandler(InvalidEmployeeIdException.class)
	public String invalidEmployeeIdException(InvalidEmployeeIdException ex) {
		String message= ex.getMessage();
		return message;
	}
	
	
	@ExceptionHandler(EmployeeAddressException.class)
	public String amployeeAddressException(EmployeeAddressException ex) {
		String message= ex.getMessage();
		return message;
	}
	
	
	@ExceptionHandler(AlreadyExistsException.class)
	public String alreadyExistsException(AlreadyExistsException ex) {
		String message= ex.getMessage();
		return message;
	}
	
	@ExceptionHandler(CreateUserException.class)
	public String createUserException(CreateUserException ex) {
		String message= ex.getMessage();
		return message;
	}
	
	@ExceptionHandler(NotFoundException.class)
	public String notFoundException(NotFoundException ex) {
		String message= ex.getMessage();
		return message;
	}
}
