package Hrms.Dashboard.Project.service;

import java.util.List;

import Hrms.Dashboard.Project.dao.SectionInchargeResponse;
import Hrms.Dashboard.Project.model.SectionIncharge;

public interface SectionInchargeInterface {

	public SectionIncharge addSectionIncharge(SectionIncharge request);
	
	 List<SectionInchargeResponse> getSectionIncharge();
	 
	 public SectionIncharge updateSectionIncharge(SectionIncharge request);
	 
	 public void deleteSectionIncharge(String empId);
	 
	 }
