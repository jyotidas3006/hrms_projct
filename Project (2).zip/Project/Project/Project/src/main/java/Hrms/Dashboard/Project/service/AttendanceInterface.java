package Hrms.Dashboard.Project.service;

import java.time.LocalDate;
import java.util.List;

import Hrms.Dashboard.Project.dao.AttendaceHistoryResponse;
import Hrms.Dashboard.Project.dao.CheckInResponse;
import Hrms.Dashboard.Project.dao.CheckOutResponse;
import Hrms.Dashboard.Project.dao.ChekInRequest;
import Hrms.Dashboard.Project.model.AttendaceHistory;


public interface AttendanceInterface {
	
	//public CheckInResponse addtendenceLogIn(ChekInRequest  checkIn) throws Exception;
	public	CheckOutResponse attendanceCheckOut(String empId);
	public List<AttendaceHistoryResponse> getAllAttendanceList();
	public List<AttendaceHistoryResponse> trackAttendance(int year, int month);
	public AttendaceHistory getByEmployeeId(String empId);
	CheckInResponse addAttendanceLogIn(ChekInRequest checkIn) throws Exception;
  

}
