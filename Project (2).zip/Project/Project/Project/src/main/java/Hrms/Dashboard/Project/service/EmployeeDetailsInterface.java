package Hrms.Dashboard.Project.service;


import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import Hrms.Dashboard.Project.dao.EmployeeListResponce;
import Hrms.Dashboard.Project.dao.PayinformationRequest;
import Hrms.Dashboard.Project.dao.PayinformationResponse;
import Hrms.Dashboard.Project.model.Avaliableleave;
import Hrms.Dashboard.Project.model.ContactInformation;
import Hrms.Dashboard.Project.model.Employee;

public interface EmployeeDetailsInterface {

	public Employee addEmpolyeeDetails (Employee empRequest);
	
	public List<EmployeeListResponce> getEmpolyeeList();
	
	public Avaliableleave addEmployeeLeave(Avaliableleave avaliableleave);
	
	public PayinformationResponse addEmployeepayment(PayinformationRequest payinformationRequest);
	
    public ContactInformation addEmpolyeeContactInformation(ContactInformation customerAddress);
    
    public Employee uploadeIndividualPhoto(MultipartFile file) throws IOException;
    
    public List<Avaliableleave> getEmpolyeeLeaveList();
    
    public Employee updateEmployeeDetails(Employee employee);
    
    public Avaliableleave updateEmployeeLeave(Avaliableleave employee);

	

	
	
}

