package Hrms.Dashboard.Project.dao;

import java.time.LocalDate;

public class CheckInResponse {
	
	
	private String empId;
    private Integer checkInId;
    private LocalDate checkInDate;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public Integer getCheckInId() {
		return checkInId;
	}
	public void setCheckInId(Integer checkInId) {
		this.checkInId = checkInId;
	}
	public LocalDate getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(LocalDate checkInDate) {
		this.checkInDate = checkInDate;
	}



}
