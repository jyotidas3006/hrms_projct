package Hrms.Dashboard.Project.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "user")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="user_id")
	private Integer userId;
	
	@Column(name="emp_Id")
	private String empId;						
	
	@Column(name ="user_name")
	private String userName;
	
	@Column(name ="user_email")
	private String userEmail;
	
	@Column(name ="hash_password")
	private String hashPassword;
	
	
	@Column(name ="user_roles")
	private String userRoles;
	
	@Column(name ="section_incharge")
	private String sectionIncharge;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public User(Integer userId, String empId, String userName, String userEmail, String hashPassword,
			 String userRoles, String sectionIncharge) {
		super();
		this.userId = userId;
		this.empId = empId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.hashPassword = hashPassword;
		this.userRoles = userRoles;
		this.sectionIncharge = sectionIncharge;
	}



	public Integer getUserId() {
		return userId;
	}



	public void setUserId(Integer userId) {
		this.userId = userId;
	}



	public String getEmpId() {
		return empId;
	}



	public void setEmpId(String empId) {
		this.empId = empId;
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



	public String getUserEmail() {
		return userEmail;
	}



	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}



	public String getHashPassword() {
		return hashPassword;
	}



	public void setHashPassword(String hashPassword) {
		this.hashPassword = hashPassword;
	}



	



	public String getUserRoles() {
		return userRoles;
	}



	public void setUserRoles(String userRoles) {
		this.userRoles = userRoles;
	}



	public String getSectionIncharge() {
		return sectionIncharge;
	}



	public void setSectionIncharge(String sectionIncharge) {
		this.sectionIncharge = sectionIncharge;
	}



	@Override
	public String toString() {
		return "User [userId=" + userId + ", empId=" + empId + ", userName=" + userName + ", userEmail=" + userEmail
				+ ", hashPassword=" + hashPassword + ",  userRoles=" + userRoles
				+ ", sectionIncharge=" + sectionIncharge + "]";
	}



	public boolean isPresent() {
		// TODO Auto-generated method stub
		return false;
	}
	
	
	
}
