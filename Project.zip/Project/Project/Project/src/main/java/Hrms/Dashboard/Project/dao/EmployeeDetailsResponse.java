package Hrms.Dashboard.Project.dao;

import java.util.Date;

public class EmployeeDetailsResponse {
	
	
    private Long id;
    
    private String empId;
    
    private String empName;
    
    private String gender;
    
    private Date dateOfBirth;
    
    private String empType;
    
    private String hashPassword;
    
    private Date dateOfJoining;
    
    private Date dateOfRetirement;
    
    private String trade;
    
    private String jobType;
    
    private String pensionPlan;
    
    private String gpfOpsNpsNo;
    
    private String panNo;
    
    private Long  aadharNo;
    
    private String gradeName;
    
    private String bloodgroupName;
    
    private String religionName;
    
    private Boolean physicallyChallenged;
    
    private String promotionMacp;
    
    private String addCategory;
    
    private String schemName;
    
    private String remarks;
    
    private String individualPhoto;
    
    private String groupPhoto;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getEmpType() {
		return empType;
	}

	public void setEmpType(String empType) {
		this.empType = empType;
	}

	public String getHashPassword() {
		return hashPassword;
	}

	public void setHashPassword(String hashPassword) {
		this.hashPassword = hashPassword;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public Date getDateOfRetirement() {
		return dateOfRetirement;
	}

	public void setDateOfRetirement(Date dateOfRetirement) {
		this.dateOfRetirement = dateOfRetirement;
	}

	public String getTrade() {
		return trade;
	}

	public void setTrade(String trade) {
		this.trade = trade;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getPensionPlan() {
		return pensionPlan;
	}

	public void setPensionPlan(String pensionPlan) {
		this.pensionPlan = pensionPlan;
	}

	public String getGpfOpsNpsNo() {
		return gpfOpsNpsNo;
	}

	public void setGpfOpsNpsNo(String gpfOpsNpsNo) {
		this.gpfOpsNpsNo = gpfOpsNpsNo;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	public Long getAadharNo() {
		return aadharNo;
	}

	public void setAadharNo(Long aadharNo) {
		this.aadharNo = aadharNo;
	}

	public String getGradeName() {
		return gradeName;
	}

	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}

	public String getBloodgroupName() {
		return bloodgroupName;
	}

	public void setBloodgroupName(String bloodgroupName) {
		this.bloodgroupName = bloodgroupName;
	}

	public String getReligionName() {
		return religionName;
	}

	public void setReligionName(String religionName) {
		this.religionName = religionName;
	}

	public Boolean getPhysicallyChallenged() {
		return physicallyChallenged;
	}

	public void setPhysicallyChallenged(Boolean physicallyChallenged) {
		this.physicallyChallenged = physicallyChallenged;
	}

	public String getPromotionMacp() {
		return promotionMacp;
	}

	public void setPromotionMacp(String promotionMacp) {
		this.promotionMacp = promotionMacp;
	}

	public String getAddCategory() {
		return addCategory;
	}

	public void setAddCategory(String addCategory) {
		this.addCategory = addCategory;
	}

	public String getSchemName() {
		return schemName;
	}

	public void setSchemName(String schemName) {
		this.schemName = schemName;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getIndividualPhoto() {
		return individualPhoto;
	}

	public void setIndividualPhoto(String individualPhoto) {
		this.individualPhoto = individualPhoto;
	}

	public String getGroupPhoto() {
		return groupPhoto;
	}

	public void setGroupPhoto(String groupPhoto) {
		this.groupPhoto = groupPhoto;
	}

    

}
