package Hrms.Dashboard.Project.dao;

import org.springframework.http.HttpStatus;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@NoArgsConstructor
@Setter

public class ResponseEntity<T> {

	String code = String.valueOf(HttpStatus.OK.value());
    String message;
    T data;

    public ResponseEntity(T data, String message){
    	this.data = data;
    	this.message = message;
    }

	
	

}