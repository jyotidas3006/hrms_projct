package Hrms.Dashboard.Project.repositoty;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Hrms.Dashboard.Project.model.Employee;

@Repository
public interface EmployeeDetailsRepo  extends JpaRepository<Employee, Integer> {
	
	
}
