package Hrms.Dashboard.Project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Hrms.Dashboard.Project.model.Avaliableleave;
import Hrms.Dashboard.Project.model.Employee;
import Hrms.Dashboard.Project.repositoty.EmployeeDetailsRepo;
import Hrms.Dashboard.Project.repositoty.EmployeeLeaveRepo;

@Service
public class EmployeeDetailsService  implements EmployeeDetailsInterface{

	@Autowired
	private EmployeeDetailsRepo employeeDetailsRepo;
	
	@Autowired
	private	EmployeeLeaveRepo employeeLeaveRepo;

	@Override
	public  Employee addEmpolyeeDetails(Employee  empRequest) {
		return  employeeDetailsRepo.save(empRequest);
	}

	@Override
	public List<Employee> getEmpolyeeDetails() {
		return employeeDetailsRepo.findAll();
	}

	@Override
	public Avaliableleave addEmployeeLeave(Avaliableleave avaliableleave) {
		return employeeLeaveRepo.save(avaliableleave);
	}
	

}
