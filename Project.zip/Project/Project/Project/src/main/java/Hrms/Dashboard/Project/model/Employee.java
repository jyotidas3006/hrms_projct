package Hrms.Dashboard.Project.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import java.util.Date;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "employee")
public class Employee {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name= "id")
	    private Long id;
	    
	    @Column(name= "emp_Id")
	    private String empId;
	    
	    @Column(name= "emp_Name")
	    private String empName;
	    
	    @Column(name= "gender_Name")
	    private String gender;
	    
	    @Column(name= "date_Of_Birth")
	    private Date dateOfBirth;
	    
	    @Column(name= "emp_Type")
	    private String empType;
	    
	    @Column(name= "hash_Password ")
	    private String hashPassword;
	    
	    @Column(name= "date_Of_Joining")
	    private Date dateOfJoining;
	    
	    @Column(name= "date_Of_Retirement")
	    private Date dateOfRetirement;
	    
	    @Column(name= "trade ")
	    private String trade;
	    
	    @Column(name= "job_Type")
	    private String jobType;
	    
	    @Column(name= "pension_Plan ")
	    private String pensionPlan;
	    
	    @Column(name= "gpf_Ops_Nps_No ")
	    private String gpfOpsNpsNo;
	    
	    @Column(name= "pan_No ")
	    private String panNo;
	    
	    @Column(name= "aadhar_No ")
	    private Long  aadharNo;
	    
	    @Column(name= "grade_type ")
	    private String gradeName;
	    
	    @Column(name= "bloodgroup_Type ")
	    private String bloodgroupName;
	    
	    @Column(name= "religion_name ")
	    private String religionName;
	    
	    @Column(name= "physically_Challenged ")
	    private Boolean physicallyChallenged;
	    
	    @Column(name= "Promotion_MACP ")
	    private String promotionMacp;
	    
	    @Column(name= "category_name ")
	    private String addCategory;
	    
	    @Column(name= "scheme_type ")
	    private String schemName;
	    
	    @Column(name= "remarks  ")
	    private String remarks;
	    
	    @Column(name= "individual_Photo ")
	    private String individualPhoto;
	    
	    @Column(name= "group_Photo ")
	    private String groupPhoto;

		public Employee() {
			super();
			
		}

		public Employee(Long id, String empId, String empName, String gender, Date dateOfBirth, String empType,
				String hashPassword, Date dateOfJoining, Date dateOfRetirement, String trade, String jobType,
				String pensionPlan, String gpfOpsNpsNo, String panNo, Long aadharNo, String gradeName,
				String bloodgroupName, String religionName, Boolean physicallyChallenged, String promotionMacp,
				String addCategory, String schemName, String remarks, String individualPhoto, String groupPhoto) {
			super();
			this.id = id;
			this.empId = empId;
			this.empName = empName;
			this.gender = gender;
			this.dateOfBirth = dateOfBirth;
			this.empType = empType;
			this.hashPassword = hashPassword;
			this.dateOfJoining = dateOfJoining;
			this.dateOfRetirement = dateOfRetirement;
			this.trade = trade;
			this.jobType = jobType;
			this.pensionPlan = pensionPlan;
			this.gpfOpsNpsNo = gpfOpsNpsNo;
			this.panNo = panNo;
			this.aadharNo = aadharNo;
			this.gradeName = gradeName;
			this.bloodgroupName = bloodgroupName;
			this.religionName = religionName;
			this.physicallyChallenged = physicallyChallenged;
			this.promotionMacp = promotionMacp;
			this.addCategory = addCategory;
			this.schemName = schemName;
			this.remarks = remarks;
			this.individualPhoto = individualPhoto;
			this.groupPhoto = groupPhoto;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getEmpId() {
			return empId;
		}

		public void setEmpId(String empId) {
			this.empId = empId;
		}

		public String getEmpName() {
			return empName;
		}

		public void setEmpName(String empName) {
			this.empName = empName;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public Date getDateOfBirth() {
			return dateOfBirth;
		}

		public void setDateOfBirth(Date dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}

		public String getEmpType() {
			return empType;
		}

		public void setEmpType(String empType) {
			this.empType = empType;
		}

		public String getHashPassword() {
			return hashPassword;
		}

		public void setHashPassword(String hashPassword) {
			this.hashPassword = hashPassword;
		}

		public Date getDateOfJoining() {
			return dateOfJoining;
		}

		public void setDateOfJoining(Date dateOfJoining) {
			this.dateOfJoining = dateOfJoining;
		}

		public Date getDateOfRetirement() {
			return dateOfRetirement;
		}

		public void setDateOfRetirement(Date dateOfRetirement) {
			this.dateOfRetirement = dateOfRetirement;
		}

		public String getTrade() {
			return trade;
		}

		public void setTrade(String trade) {
			this.trade = trade;
		}

		public String getJobType() {
			return jobType;
		}

		public void setJobType(String jobType) {
			this.jobType = jobType;
		}

		public String getPensionPlan() {
			return pensionPlan;
		}

		public void setPensionPlan(String pensionPlan) {
			this.pensionPlan = pensionPlan;
		}

		public String getGpfOpsNpsNo() {
			return gpfOpsNpsNo;
		}

		public void setGpfOpsNpsNo(String gpfOpsNpsNo) {
			this.gpfOpsNpsNo = gpfOpsNpsNo;
		}

		public String getPanNo() {
			return panNo;
		}

		public void setPanNo(String panNo) {
			this.panNo = panNo;
		}

		public Long getAadharNo() {
			return aadharNo;
		}

		public void setAadharNo(Long aadharNo) {
			this.aadharNo = aadharNo;
		}

		public String getGradeName() {
			return gradeName;
		}

		public void setGradeName(String gradeName) {
			this.gradeName = gradeName;
		}

		public String getBloodgroupName() {
			return bloodgroupName;
		}

		public void setBloodgroupName(String bloodgroupName) {
			this.bloodgroupName = bloodgroupName;
		}

		public String getReligionName() {
			return religionName;
		}

		public void setReligionName(String religionName) {
			this.religionName = religionName;
		}

		public Boolean getPhysicallyChallenged() {
			return physicallyChallenged;
		}

		public void setPhysicallyChallenged(Boolean physicallyChallenged) {
			this.physicallyChallenged = physicallyChallenged;
		}

		public String getPromotionMacp() {
			return promotionMacp;
		}

		public void setPromotionMacp(String promotionMacp) {
			this.promotionMacp = promotionMacp;
		}

		public String getAddCategory() {
			return addCategory;
		}

		public void setAddCategory(String addCategory) {
			this.addCategory = addCategory;
		}

		public String getSchemName() {
			return schemName;
		}

		public void setSchemName(String schemName) {
			this.schemName = schemName;
		}

		public String getRemarks() {
			return remarks;
		}

		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}

		public String getIndividualPhoto() {
			return individualPhoto;
		}

		public void setIndividualPhoto(String individualPhoto) {
			this.individualPhoto = individualPhoto;
		}

		public String getGroupPhoto() {
			return groupPhoto;
		}

		public void setGroupPhoto(String groupPhoto) {
			this.groupPhoto = groupPhoto;
		}

		@Override
		public String toString() {
			return "Employee [id=" + id + ", empId=" + empId + ", empName=" + empName + ", gender=" + gender
					+ ", dateOfBirth=" + dateOfBirth + ", empType=" + empType + ", hashPassword=" + hashPassword
					+ ", dateOfJoining=" + dateOfJoining + ", dateOfRetirement=" + dateOfRetirement + ", trade=" + trade
					+ ", jobType=" + jobType + ", pensionPlan=" + pensionPlan + ", gpfOpsNpsNo=" + gpfOpsNpsNo
					+ ", panNo=" + panNo + ", aadharNo=" + aadharNo + ", gradeName=" + gradeName + ", bloodgroupName="
					+ bloodgroupName + ", religionName=" + religionName + ", physicallyChallenged="
					+ physicallyChallenged + ", promotionMacp=" + promotionMacp + ", addCategory=" + addCategory
					+ ", schemName=" + schemName + ", remarks=" + remarks + ", individualPhoto=" + individualPhoto
					+ ", groupPhoto=" + groupPhoto + "]";
		}
		
		

}