package Hrms.Dashboard.Project.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "availableleave")
public class Avaliableleave {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="availableleave_id")
	private Long AvailableleaveId;
	
	@Column(name ="el")
	private Long el;						
	
	@Column(name ="cl")
	private Long cl;
	
	@Column(name ="commuted_hpl")
	private Long commutedHpl;
	
	@Column(name ="hpl")
	private Long hpl;
	
	@Column(name ="otl_comp_off")
	private Long otlCompOff;
	
	@Column(name ="eol_without_mc")
	private Long eolWithoutMc;
	
	@Column(name ="ccl")
	private Long ccl;
	
	@Column(name ="paternity_leave")
	private Long paternityLeave;
	
	@Column(name ="maternity_leave")
	private Long maternityLeave;
	
	@Column(name ="eol_with_mc")
	private Long eolWithMc;
	
	
	
	@Column(name ="ssl_leave")
	private Long sslLeave;
	
	  
    @Column(name= "emp_Id")
    private String empId;

	public Avaliableleave() {
		super();
		
	}

	public Avaliableleave(Long availableleaveId, Long el, Long cl, Long commutedHpl, Long hpl, Long otlCompOff,
			Long eolWithoutMc, Long ccl, Long paternityLeave, Long maternityLeave, Long eolWithMc, Long sslLeave,
			String empId) {
		super();
		this.AvailableleaveId = availableleaveId;
		this.el = el;
		this.cl = cl;
		this.commutedHpl = commutedHpl;
		this.hpl = hpl;
		this.otlCompOff = otlCompOff;
		this.eolWithoutMc = eolWithoutMc;
		this.ccl = ccl;
		this.paternityLeave = paternityLeave;
		this.maternityLeave = maternityLeave;
		this.eolWithMc = eolWithMc;
		this.sslLeave = sslLeave;
		this.empId = empId;
	}

	public Long getAvailableleaveId() {
		return AvailableleaveId;
	}

	public void setAvailableleaveId(Long availableleaveId) {
		AvailableleaveId = availableleaveId;
	}

	public Long getEl() {
		return el;
	}

	public void setEl(Long el) {
		this.el = el;
	}

	public Long getCl() {
		return cl;
	}

	public void setCl(Long cl) {
		this.cl = cl;
	}

	public Long getCommutedHpl() {
		return commutedHpl;
	}

	public void setCommutedHpl(Long commutedHpl) {
		this.commutedHpl = commutedHpl;
	}

	public Long getHpl() {
		return hpl;
	}

	public void setHpl(Long hpl) {
		this.hpl = hpl;
	}

	public Long getOtlCompOff() {
		return otlCompOff;
	}

	public void setOtlCompOff(Long otlCompOff) {
		this.otlCompOff = otlCompOff;
	}

	public Long getEolWithoutMc() {
		return eolWithoutMc;
	}

	public void setEolWithoutMc(Long eolWithoutMc) {
		this.eolWithoutMc = eolWithoutMc;
	}

	public Long getCcl() {
		return ccl;
	}

	public void setCcl(Long ccl) {
		this.ccl = ccl;
	}

	public Long getPaternityLeave() {
		return paternityLeave;
	}

	public void setPaternityLeave(Long paternityLeave) {
		this.paternityLeave = paternityLeave;
	}

	public Long getMaternityLeave() {
		return maternityLeave;
	}

	public void setMaternityLeave(Long maternityLeave) {
		this.maternityLeave = maternityLeave;
	}

	public Long getEolWithMc() {
		return eolWithMc;
	}

	public void setEolWithMc(Long eolWithMc) {
		this.eolWithMc = eolWithMc;
	}

	public Long getSslLeave() {
		return sslLeave;
	}

	public void setSslLeave(Long sslLeave) {
		this.sslLeave = sslLeave;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	@Override
	public String toString() {
		return "Avaliableleave [AvailableleaveId=" + AvailableleaveId + ", el=" + el + ", cl=" + cl + ", commutedHpl="
				+ commutedHpl + ", hpl=" + hpl + ", otlCompOff=" + otlCompOff + ", eolWithoutMc=" + eolWithoutMc
				+ ", ccl=" + ccl + ", paternityLeave=" + paternityLeave + ", maternityLeave=" + maternityLeave
				+ ", eolWithMc=" + eolWithMc + ", sslLeave=" + sslLeave + ", empId=" + empId + "]";
	}



	



	



	
}
