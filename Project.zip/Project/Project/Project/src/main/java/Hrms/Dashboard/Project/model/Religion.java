package Hrms.Dashboard.Project.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "religion")
public class Religion {
	

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="religion_Id")
	private Long religionId;
	
	
	@Column(name="religion_name")
	private String religionName;
	

}
