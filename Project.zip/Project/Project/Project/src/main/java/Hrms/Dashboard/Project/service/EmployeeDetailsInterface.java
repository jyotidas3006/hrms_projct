package Hrms.Dashboard.Project.service;


import java.util.List;

import Hrms.Dashboard.Project.model.Avaliableleave;
import Hrms.Dashboard.Project.model.Employee;

public interface EmployeeDetailsInterface {

	public Employee addEmpolyeeDetails (Employee empRequest);
	
	public List <Employee> getEmpolyeeDetails ( );
	
	public Avaliableleave addEmployeeLeave(Avaliableleave avaliableleave);
	
}
