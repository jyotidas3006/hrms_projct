package Hrms.Dashboard.Project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Hrms.Dashboard.Project.model.Avaliableleave;
import Hrms.Dashboard.Project.model.Employee;
import Hrms.Dashboard.Project.service.EmployeeDetailsInterface;


@RestController
@RequestMapping("/hrms/dashboard")
public class EmployeeDetailsController {
	
	@Autowired
	private EmployeeDetailsInterface employeeDetailsInterface;
	
	@PostMapping("/addEmployeeDetails")
	public ResponseEntity<Employee>  addEmployeeDetails (@RequestBody Employee empRequest){
		Employee employee =employeeDetailsInterface.addEmpolyeeDetails(empRequest);
		return new ResponseEntity<Employee> (employee, HttpStatus.CREATED);
	}
	
	
	@GetMapping("/Employee/List")
	public List <Employee> getEmployeeDetails (){
		return  employeeDetailsInterface.getEmpolyeeDetails();
	
	}
	

	@PostMapping("/addEmployee/Leave")
	public ResponseEntity<Avaliableleave>  addEmployeeLeave (@RequestBody Avaliableleave  empRequest){
		Avaliableleave employee =employeeDetailsInterface.addEmployeeLeave(empRequest);
		return new ResponseEntity<Avaliableleave> (employee, HttpStatus.CREATED);
	}
	
	
	
}
