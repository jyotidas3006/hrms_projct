package Hrms.Dashboard.Project.repositoty;

import org.springframework.data.jpa.repository.JpaRepository;

import Hrms.Dashboard.Project.model.Avaliableleave;

public interface EmployeeLeaveRepo extends JpaRepository<Avaliableleave, Integer>{

}
