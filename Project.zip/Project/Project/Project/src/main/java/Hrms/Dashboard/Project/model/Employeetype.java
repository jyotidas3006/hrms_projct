package Hrms.Dashboard.Project.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Data
@Table(name= "employeetype")
public class Employeetype {
	

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="employeetype_Id")
	private Long employeetypeId ;

	@Column(name="emp_Type")
	private String empType;


}
